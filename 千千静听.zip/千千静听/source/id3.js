/* =========================================================
   Minimal ID3 reader for the local player.
   Supports ID3v2.2 / v2.3 / v2.4 text frames and APIC covers,
   plus a small ID3v1 fallback.  Everything stays in the browser.
   ========================================================= */
(function (global) {
  'use strict';

  var decoderCache = {};

  function decoderFor(label) {
    if (!decoderCache[label]) {
      try {
        decoderCache[label] = new TextDecoder(label);
      } catch (error) {
        decoderCache[label] = new TextDecoder('utf-8');
      }
    }
    return decoderCache[label];
  }

  function readBlob(blob) {
    if (blob.arrayBuffer) {
      return blob.arrayBuffer();
    }
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () { resolve(reader.result); };
      reader.onerror = function () { reject(reader.error || new Error('无法读取文件')); };
      reader.readAsArrayBuffer(blob);
    });
  }

  function sliceBytes(file, start, end) {
    return readBlob(file.slice(start, end)).then(function (buffer) {
      return new Uint8Array(buffer);
    });
  }

  function ascii(bytes, start, length) {
    var value = '';
    for (var i = start; i < Math.min(bytes.length, start + length); i++) {
      var code = bytes[i];
      if (code === 0) break;
      value += String.fromCharCode(code);
    }
    return value;
  }

  function textBytes(bytes, start, end) {
    return bytes.subarray(start, Math.max(start, Math.min(end, bytes.length)));
  }

  function decodeText(bytes, encoding) {
    if (!bytes || !bytes.length) return '';
    var label = 'windows-1252';
    var offset = 0;
    if (encoding === 1) {
      if (bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xfe) {
        label = 'utf-16le';
        offset = 2;
      } else if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff) {
        label = 'utf-16be';
        offset = 2;
      } else {
        label = 'utf-16le';
      }
    } else if (encoding === 2) {
      label = 'utf-16be';
    } else if (encoding === 3) {
      label = 'utf-8';
    }
    var value = decoderFor(label).decode(bytes.subarray(offset));
    return value
      .replace(/\u0000+/g, ' / ')
      .replace(/^[\s/]+|[\s/]+$/g, '')
      .replace(/\uFFFD/g, '')
      .trim();
  }

  function decodeFixed(bytes, start, length, preferChinese) {
    var part = bytes.subarray(start, start + length);
    var end = part.length;
    while (end > 0 && (part[end - 1] === 0 || part[end - 1] === 0x20)) end--;
    part = part.subarray(0, end);
    var hasHigh = false;
    for (var i = 0; i < part.length; i++) {
      if (part[i] > 0x7f) { hasHigh = true; break; }
    }
    var label = hasHigh && preferChinese ? 'gbk' : 'windows-1252';
    try {
      return decoderFor(label).decode(part).replace(/\u0000/g, '').trim();
    } catch (error) {
      return decoderFor('windows-1252').decode(part).replace(/\u0000/g, '').trim();
    }
  }

  function syncSafe(bytes, start) {
    return ((bytes[start] & 0x7f) << 21) |
      ((bytes[start + 1] & 0x7f) << 14) |
      ((bytes[start + 2] & 0x7f) << 7) |
      (bytes[start + 3] & 0x7f);
  }

  function uint32(bytes, start) {
    return ((bytes[start] & 0xff) * 0x1000000) +
      ((bytes[start + 1] & 0xff) << 16) +
      ((bytes[start + 2] & 0xff) << 8) +
      (bytes[start + 3] & 0xff);
  }

  function findTerminator(bytes, start, encoding) {
    if (encoding === 1 || encoding === 2) {
      var alignedStart = start;
      for (var i = alignedStart; i + 1 < bytes.length; i += 2) {
        if (bytes[i] === 0 && bytes[i + 1] === 0) return i + 2;
      }
      return bytes.length;
    }
    for (var j = start; j < bytes.length; j++) {
      if (bytes[j] === 0) return j + 1;
    }
    return bytes.length;
  }

  function parseAPIC(payload, version) {
    if (!payload || payload.length < 10) return null;
    var pos = 0;
    var encoding = payload[pos++];
    var mime = 'image/jpeg';
    if (version === 2) {
      var format = ascii(payload, pos, 3).toUpperCase();
      pos += 3;
      mime = format === 'PNG' ? 'image/png' : 'image/jpeg';
    } else {
      var mimeStart = pos;
      while (pos < payload.length && payload[pos] !== 0) pos++;
      mime = ascii(payload, mimeStart, pos - mimeStart) || 'image/jpeg';
      if (pos < payload.length) pos++;
    }
    if (pos >= payload.length) return null;
    var pictureType = payload[pos++];
    var descEnd = findTerminator(payload, pos, encoding);
    pos = descEnd;
    if (pos >= payload.length) return null;
    var imageBytes = payload.subarray(pos);
    if (imageBytes.length < 128) return null;
    if (imageBytes.length > 12 * 1024 * 1024) return null;
    var normalizedMime = mime.toLowerCase();
    if (normalizedMime === 'image/jpg') normalizedMime = 'image/jpeg';
    if (normalizedMime === 'image/png') normalizedMime = 'image/png';
    var blob;
    try {
      blob = new Blob([imageBytes], { type: normalizedMime });
    } catch (error) {
      return null;
    }
    return { pictureType: pictureType, mime: normalizedMime, blob: blob };
  }

  function parseV2(tagBytes, version) {
    var result = {};
    var coverCandidates = [];
    var offset = 10;
    var tagEnd = tagBytes.length;
    var headerSize = version === 2 ? 6 : 10;

    if (version >= 3 && offset + 4 <= tagEnd) {
      var flags = tagBytes[5];
      if (flags & 0x40) {
        if (version === 3) {
          var extSize = uint32(tagBytes, offset);
          offset += 4 + extSize;
        } else {
          var extSizeV4 = syncSafe(tagBytes, offset);
          offset += Math.max(extSizeV4, 6);
        }
      }
    }

    while (offset + headerSize <= tagEnd) {
      var idLength = version === 2 ? 3 : 4;
      var id = ascii(tagBytes, offset, idLength);
      if (!id || id.charCodeAt(0) === 0) break;

      var frameSize;
      var frameHeader;
      if (version === 2) {
        frameSize = (tagBytes[offset + 3] << 16) | (tagBytes[offset + 4] << 8) | tagBytes[offset + 5];
        frameHeader = 6;
      } else if (version === 4) {
        frameSize = syncSafe(tagBytes, offset + 4);
        frameHeader = 10;
      } else {
        frameSize = uint32(tagBytes, offset + 4);
        frameHeader = 10;
      }
      if (!Number.isFinite(frameSize) || frameSize <= 0) break;
      var dataStart = offset + frameHeader;
      if (dataStart + frameSize > tagEnd) break;
      var payload = tagBytes.subarray(dataStart, dataStart + frameSize);
      var formatFlags = version >= 3 ? ((tagBytes[offset + 8] << 8) | tagBytes[offset + 9]) : 0;

      // Ignore compressed or encrypted frames, and strip a data-length prefix
      // from v2.4 frames that carry one.
      var skip = false;
      if (version === 3) {
        if (formatFlags & 0x80 || formatFlags & 0x40) skip = true;
        if (formatFlags & 0x20 && payload.length > 1) payload = payload.subarray(1);
      } else if (version === 4) {
        if (formatFlags & 0x0c) skip = true;
        if (formatFlags & 0x40 && payload.length > 1) payload = payload.subarray(1);
        if (formatFlags & 0x01 && payload.length > 4) payload = payload.subarray(4);
      }

      if (!skip) {
        if (id === 'TIT2' || id === 'TT2') {
          result.title = decodeText(payload.subarray(1), payload[0]);
        } else if (id === 'TPE1' || id === 'TP1') {
          result.artist = decodeText(payload.subarray(1), payload[0]);
        } else if (id === 'TALB' || id === 'TAL') {
          result.album = decodeText(payload.subarray(1), payload[0]);
        } else if (id === 'TYER' || id === 'TDRC' || id === 'TYE') {
          result.year = decodeText(payload.subarray(1), payload[0]);
        } else if (id === 'TRCK' || id === 'TRK') {
          result.track = decodeText(payload.subarray(1), payload[0]);
        } else if (id === 'TCON' || id === 'TCO') {
          result.genre = decodeText(payload.subarray(1), payload[0]);
        } else if (id === 'APIC' || id === 'PIC') {
          var cover = parseAPIC(payload, version);
          if (cover) coverCandidates.push(cover);
        }
      }

      offset = dataStart + frameSize;
    }

    if (coverCandidates.length) {
      var front = coverCandidates.filter(function (item) { return item.pictureType === 3; })[0];
      result.cover = (front || coverCandidates[0]).blob;
      result.coverMime = (front || coverCandidates[0]).mime;
    }
    return result;
  }

  function parseV1(bytes) {
    if (bytes.length < 128) return {};
    var start = bytes.length - 128;
    if (ascii(bytes, start, 3) !== 'TAG') return {};
    var result = {};
    var title = decodeFixed(bytes, start + 3, 30, true);
    var artist = decodeFixed(bytes, start + 33, 30, true);
    var album = decodeFixed(bytes, start + 63, 30, true);
    var year = decodeFixed(bytes, start + 93, 4, false);
    if (title) result.title = title;
    if (artist) result.artist = artist;
    if (album) result.album = album;
    if (year) result.year = year;
    if (bytes[start + 125] === 0 && bytes[start + 126] !== 0) {
      result.track = String(bytes[start + 126]);
    }
    return result;
  }

  async function read(file) {
    var result = {};
    if (!file || !file.size) return result;

    try {
      if (file.size >= 10) {
        var header = await sliceBytes(file, 0, 10);
        if (ascii(header, 0, 3) === 'ID3') {
          var version = header[3];
          var size = syncSafe(header, 6);
          var total = Math.min(file.size, 10 + size + (version === 4 ? 10 : 0));
          var readEnd = Math.min(total, 14 * 1024 * 1024);
          var tagBytes = readEnd === 10 ? header : await sliceBytes(file, 0, readEnd);
          if (version >= 2 && version <= 4) {
            result = parseV2(tagBytes, version);
          }
        }
      }
    } catch (error) {
      result = {};
    }

    if (!result.title || !result.artist || !result.album) {
      try {
        if (file.size >= 128) {
          var tail = await sliceBytes(file, Math.max(0, file.size - 128), file.size);
          var v1 = parseV1(tail);
          Object.keys(v1).forEach(function (key) {
            if (!result[key]) result[key] = v1[key];
          });
        }
      } catch (error) {
        // No ID3v1 tag, or the tail could not be read.
      }
    }

    if (result.year) result.year = String(result.year).slice(0, 4);
    return result;
  }

  global.ID3 = { read: read };
})(window);
