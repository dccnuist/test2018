#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Package the browser app into a small zip embedded inside the EXE."""
import os
import sys
import zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
INCLUDE = [
    'index.html',
    'style.css',
    'app.js',
    'id3.js',
    'assets/logo.svg',
    'assets/demo-cover.svg',
    'assets/icon.ico',
    'demo/晚风电台.wav',
    'demo/晚风电台.lrc',
]

def main():
    output = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, '.build', 'web.zip')
    os.makedirs(os.path.dirname(output), exist_ok=True)
    missing = [item for item in INCLUDE if not os.path.exists(os.path.join(ROOT, item))]
    if missing:
        raise SystemExit('missing payload: ' + ', '.join(missing))
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for relative in INCLUDE:
            source = os.path.join(ROOT, relative)
            archive.write(source, relative)
    print('packed %d files -> %s (%.2f MB)' % (
        len(INCLUDE), output, os.path.getsize(output) / 1048576.0))

if __name__ == '__main__':
    main()
