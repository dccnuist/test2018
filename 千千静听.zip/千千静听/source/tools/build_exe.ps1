﻿# Build the single-file Windows executable using only the tools already on this PC.
# It uses the .NET Framework C# compiler and the WebView2 runtime/SDK components
# already present on the machine. No packages are installed or downloaded.

$ErrorActionPreference = 'Stop'
$sourceRoot = Split-Path -Parent $PSScriptRoot
$root = Split-Path -Parent $sourceRoot
$build = Join-Path $sourceRoot '.build'
$csc = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'

if (-not (Test-Path $csc)) {
    throw '找不到 .NET Framework C# 编译器。'
}

$sdkCandidates = @(
    @{
        Core = 'C:\Program Files\Microsoft OfficePLUS\3.8.0.13669\exceladdin\Microsoft.Web.WebView2.Core.dll'
        WinForms = 'C:\Program Files\Microsoft OfficePLUS\3.8.0.13669\exceladdin\Microsoft.Web.WebView2.WinForms.dll'
        Loader = 'C:\Program Files\Microsoft OfficePLUS\3.8.0.13669\exceladdin\runtimes\win-x64\native\WebView2Loader.dll'
    },
    @{
        Core = 'C:\Program Files\Huawei\PCManager\Microsoft.Web.WebView2.Core.dll'
        WinForms = 'C:\Program Files\Huawei\PCManager\Microsoft.Web.WebView2.WinForms.dll'
        Loader = 'C:\Program Files\Huawei\PCManager\runtimes\win-x64\native\WebView2Loader.dll'
    }
)
$sdk = $sdkCandidates | Where-Object {
    (Test-Path $_.Core) -and (Test-Path $_.WinForms) -and (Test-Path $_.Loader)
} | Select-Object -First 1
if (-not $sdk) {
    throw '找不到系统中已有的 WebView2 SDK 程序集。'
}

New-Item -ItemType Directory -Force -Path $build | Out-Null
$payload = Join-Path $build 'web.zip'
python (Join-Path $sourceRoot 'tools\package_web.py') $payload

$out = Join-Path $root '千千静听.exe'
$arguments = @(
    '/nologo',
    '/target:winexe',
    '/platform:x64',
    '/optimize+',
    '/codepage:65001',
    '/langversion:5',
    ('/win32icon:' + (Join-Path $sourceRoot 'assets\icon.ico')),
    ('/win32manifest:' + (Join-Path $sourceRoot 'native\app.manifest')),
    ('/out:' + $out),
    ('/resource:' + $payload + ',QianQian.web.zip'),
    ('/resource:' + $sdk.Core + ',QianQian.WebView2.Core.dll'),
    ('/resource:' + $sdk.WinForms + ',QianQian.WebView2.WinForms.dll'),
    ('/resource:' + $sdk.Loader + ',QianQian.WebView2Loader.dll'),
    '/reference:System.dll',
    '/reference:System.Core.dll',
    '/reference:System.Drawing.dll',
    '/reference:System.Windows.Forms.dll',
    '/reference:System.IO.Compression.dll',
    ('/reference:' + $sdk.Core),
    ('/reference:' + $sdk.WinForms),
    (Join-Path $sourceRoot 'native\PlayerForm.cs')
)

& $csc $arguments
if ($LASTEXITCODE -ne 0) {
    throw ('C# 编译失败，退出码 ' + $LASTEXITCODE)
}
if (-not (Test-Path $out)) {
    throw '没有生成 EXE。'
}

$info = Get-Item $out
Write-Host ('BUILT ' + $info.FullName)
Write-Host ('SIZE  ' + [math]::Round($info.Length / 1MB, 2) + ' MB')
