#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate the original demo track bundled with the player.

Only the Python standard library is used.  The result is a 32-second,
mono 32 kHz WAV file: a soft, nostalgic late-night arpeggio loop.
"""
import array
import math
import os
import random
import struct
import wave

SR = 32000
DURATION = 32.0
N = int(SR * DURATION)
random.seed(2006)

# Chords (bass + pad voicing), repeated twice.
CHORDS = [
    [130.81, 261.63, 329.63, 392.00, 493.88],  # Cmaj7
    [110.00, 220.00, 261.63, 329.63, 392.00],  # Am7
    [87.31, 174.61, 220.00, 261.63, 329.63],   # Fmaj7
    [98.00, 196.00, 246.94, 293.66, 329.63],   # G6
]
PROGRESSION = [0, 1, 2, 3, 0, 2, 1, 3]
ARP = [1, 2, 3, 4, 3, 2, 4, 3]

buf = [0.0] * N


def add_tone(start, freq, length, amp, harmonics=((1, 1.0), (2, .22), (3, .08)),
             attack=.01, decay=3.0, vibrato=0.0):
    begin = int(start * SR)
    end = min(N, int((start + length) * SR))
    if begin >= N:
        return
    step = 2.0 * math.pi * freq / SR
    vib_step = 2.0 * math.pi * 4.6 / SR
    for i in range(begin, end):
        t = (i - begin) / SR
        env_a = min(1.0, t / attack) if attack > 0 else 1.0
        env = env_a * math.exp(-decay * t)
        if env < 0.00001:
            continue
        phase = step * t
        if vibrato:
            phase += vibrato * math.sin(vib_step * t)
        value = 0.0
        for mult, weight in harmonics:
            value += math.sin(phase * mult) * weight
        buf[i] += value * env * amp


# Pads + bass + arpeggios.
bar_len = 4.0
for bar, chord_index in enumerate(PROGRESSION):
    chord = CHORDS[chord_index]
    start = bar * bar_len
    # Warm sustained pad.
    for voice, freq in enumerate(chord[1:]):
        add_tone(start, freq, bar_len + 1.1, 0.026 - voice * 0.002,
                 harmonics=((1, 1.0), (2, .12)), attack=.9, decay=.15,
                 vibrato=.25)
    # Root bass, two pulses per bar.
    add_tone(start, chord[0] / 2, 2.1, .085, harmonics=((1, 1.0), (2, .18)),
             attack=.05, decay=1.25)
    add_tone(start + 2.0, chord[0] / 2, 2.0, .06, harmonics=((1, 1.0), (2, .14)),
             attack=.08, decay=1.5)
    # Finger-picked arpeggio.
    for step, note in enumerate(ARP):
        offset = start + step * .5
        add_tone(offset, chord[note] * 2, 1.65, .048,
                 harmonics=((1, 1.0), (2, .32), (3, .12), (4, .05)),
                 attack=.006, decay=2.8)
    # A single high bell at the opening of each bar.
    add_tone(start + .05, chord[3] * 4, 2.8, .016,
             harmonics=((1, 1.0), (2, .2), (3, .07)), attack=.008, decay=1.45,
             vibrato=.5)

# Soft brushed shaker, deterministic and unobtrusive.
for beat in range(int(DURATION / .5)):
    start = beat * .5 + .25
    begin = int(start * SR)
    end = min(N, begin + int(.18 * SR))
    for i in range(begin, end):
        t = (i - begin) / SR
        env = math.exp(-34.0 * t) * min(1.0, t / .004)
        # Difference of two noise values gives a light high-passed tick.
        n = (random.random() * 2.0 - 1.0)
        n2 = (random.random() * 2.0 - 1.0)
        buf[i] += (n - n2 * .55) * env * .009

# Simple two-tap echo for a small-room ambience.
echo = list(buf)
d1, d2 = int(.235 * SR), int(.377 * SR)
for i in range(d1, N):
    echo[i] += buf[i - d1] * .18
for i in range(d2, N):
    echo[i] += buf[i - d2] * .10
buf = echo

# Gentle fade in / fade out and peak normalisation.
peak = max(1e-8, max(abs(v) for v in buf))
scale = .84 / peak
fade_in = int(2.2 * SR)
fade_out = int(4.0 * SR)
for i in range(N):
    gain = scale
    if i < fade_in:
        gain *= i / fade_in
    if i > N - fade_out:
        gain *= max(0.0, (N - i) / fade_out)
    buf[i] *= gain

out = array.array('h')
for value in buf:
    out.append(int(max(-1.0, min(1.0, value)) * 32767))

out_path = os.path.join(os.path.dirname(__file__), '..', 'demo', '晚风电台.wav')
out_path = os.path.abspath(out_path)
os.makedirs(os.path.dirname(out_path), exist_ok=True)
with wave.open(out_path, 'wb') as wav:
    wav.setnchannels(1)
    wav.setsampwidth(2)
    wav.setframerate(SR)
    wav.writeframes(out.tobytes())
print('WROTE', out_path, '%.1f MB' % (os.path.getsize(out_path) / 1048576.0))
