using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

[assembly: AssemblyTitle("千千静听")]
[assembly: AssemblyProduct("千千静听 · 本地音乐播放器")]
[assembly: AssemblyDescription("向经典致敬的本地音乐播放器")]
[assembly: AssemblyCompany("Local")]
[assembly: AssemblyCopyright("Classic tribute, local only")]
[assembly: AssemblyVersion("5.0.0.0")]
[assembly: AssemblyFileVersion("5.0.0.0")]

namespace QianQianClassic
{
    internal static class StartupLog
    {
        private static readonly object Sync = new object();

        public static void Write(string message)
        {
            if (Environment.GetEnvironmentVariable("QIANQIAN_DEBUG") != "1") return;
            string line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + "  " + message + "\r\n";
            string[] folders = new string[]
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "QianQianClassic"),
                Path.GetTempPath(),
                AppDomain.CurrentDomain.BaseDirectory
            };
            for (int index = 0; index < folders.Length; index++)
            {
                try
                {
                    Directory.CreateDirectory(folders[index]);
                    lock (Sync)
                    {
                        File.AppendAllText(Path.Combine(folders[index], "startup.log"), line, Encoding.UTF8);
                    }
                    return;
                }
                catch
                {
                    // Try the next location.
                }
            }
        }
    }

    internal static class Program
    {
        private const string CoreResource = "QianQian.WebView2.Core.dll";
        private const string WinFormsResource = "QianQian.WebView2.WinForms.dll";
        private const string LoaderResource = "QianQian.WebView2Loader.dll";

        [STAThread]
        private static void Main()
        {
            StartupLog.Write("Main start");
            AppDomain.CurrentDomain.AssemblyResolve += ResolveWebView2Assembly;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                RunPlayer();
                StartupLog.Write("Application.Run returned");
            }
            catch (Exception error)
            {
                StartupLog.Write("FATAL: " + error);
                MessageBox.Show(
                    "千千静听启动失败。\r\n\r\n" + error.Message,
                    "千千静听",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        private static void RunPlayer()
        {
            string loaderFolder = ExtractLoader();
            StartupLog.Write("loader folder: " + loaderFolder);
            try
            {
                CoreWebView2Environment.SetLoaderDllFolderPath(loaderFolder);
                StartupLog.Write("loader path set");
            }
            catch
            {
                // Older WebView2 SDKs fall back to the normal DLL search path.
            }
            Application.Run(new PlayerForm());
        }

        private static Assembly ResolveWebView2Assembly(object sender, ResolveEventArgs args)
        {
            AssemblyName requested = new AssemblyName(args.Name);
            string name = requested.Name;
            string resource = null;
            if (string.Equals(name, "Microsoft.Web.WebView2.Core", StringComparison.OrdinalIgnoreCase))
                resource = CoreResource;
            else if (string.Equals(name, "Microsoft.Web.WebView2.WinForms", StringComparison.OrdinalIgnoreCase))
                resource = WinFormsResource;
            if (resource == null)
                return null;

            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource))
            {
                if (stream == null)
                    return null;
                byte[] bytes = new byte[stream.Length];
                int read = 0;
                while (read < bytes.Length)
                {
                    int chunk = stream.Read(bytes, read, bytes.Length - read);
                    if (chunk <= 0) break;
                    read += chunk;
                }
                if (read != bytes.Length)
                    return null;
                return Assembly.Load(bytes);
            }
        }

        private static string ExtractLoader()
        {
            string preferred = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "QianQianClassic",
                "bin");
            string[] candidates = new string[]
            {
                preferred,
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ".data", "bin")
            };
            Exception lastError = null;
            for (int index = 0; index < candidates.Length; index++)
            {
                try
                {
                    string folder = candidates[index];
                    Directory.CreateDirectory(folder);
                    string target = Path.Combine(folder, "WebView2Loader.dll");
                    using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(LoaderResource))
                    {
                        if (stream == null)
                            throw new InvalidOperationException("安装包缺少 WebView2Loader。");
                        bool write = true;
                        if (File.Exists(target) && new FileInfo(target).Length == stream.Length)
                            write = false;
                        if (write)
                        {
                            string temporary = target + "." + Guid.NewGuid().ToString("N") + ".tmp";
                            using (FileStream output = new FileStream(temporary, FileMode.Create, FileAccess.Write, FileShare.None))
                            {
                                stream.CopyTo(output);
                            }
                            try
                            {
                                if (File.Exists(target))
                                    File.Delete(target);
                                File.Move(temporary, target);
                            }
                            catch
                            {
                                try { File.Delete(temporary); } catch { }
                            }
                        }
                    }
                    return folder;
                }
                catch (Exception error)
                {
                    lastError = error;
                }
            }
            throw new InvalidOperationException("无法释放 WebView2 加载组件。", lastError);
        }
    }

    internal sealed class PlayerForm : Form
    {
        private const int WM_NCHITTEST = 0x0084;
        private const int HTCLIENT = 1;
        private const int HTCAPTION = 2;
        private const int HTLEFT = 10;
        private const int HTRIGHT = 11;
        private const int HTTOP = 12;
        private const int HTTOPLEFT = 13;
        private const int HTTOPRIGHT = 14;
        private const int HTBOTTOM = 15;
        private const int HTBOTTOMLEFT = 16;
        private const int HTBOTTOMRIGHT = 17;
        private const int WM_NCLBUTTONDOWN = 0x00A1;

        [DllImport("user32.dll")]
        private static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

        private const string AppHost = "https://qianqian.local/";
        private WebView2 _web;
        private Panel _splash;
        private Label _splashTitle;
        private Label _splashSub;
        private CoreWebView2Environment _environment;
        private Dictionary<string, byte[]> _files;
        private bool _lastMaximized;
        private Timer _debugTimer;
        private int _debugTicks;

        public PlayerForm()
        {
            Text = "千千静听 · 本地音乐播放器";
            BackColor = Color.FromArgb(7, 21, 35);
            ForeColor = Color.FromArgb(216, 237, 245);
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(960, 620);
            DoubleBuffered = true;
            KeyPreview = false;

            try
            {
                Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            }
            catch
            {
                // The embedded icon is optional.
            }

            Size preferred = GetPreferredSize();
            ClientSize = preferred;
            BuildSplash();
            BuildWebView();
            Shown += OnPlayerShown;
            Resize += OnPlayerResize;
        }

        private Size GetPreferredSize()
        {
            Rectangle work = Screen.PrimaryScreen.WorkingArea;
            float scale = 1f;
            try
            {
                using (Graphics graphics = Graphics.FromHwnd(IntPtr.Zero))
                {
                    scale = graphics.DpiX / 96f;
                }
            }
            catch
            {
                scale = 1f;
            }
            if (scale <= 0.5f) scale = 1f;
            int width = Math.Min(1220, Math.Max(980, (int)(work.Width / scale) - 24));
            int height = Math.Min(860, Math.Max(600, (int)(work.Height / scale) - 6));
            StartupLog.Write("screen " + work.Width + "x" + work.Height + " scale " + scale.ToString("0.00") + " client " + width + "x" + height);
            return new Size(width, height);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams parameters = base.CreateParams;
                parameters.ClassStyle |= 0x00020000; // CS_DROPSHADOW
                return parameters;
            }
        }

        private void BuildSplash()
        {
            _splash = new Panel();
            _splash.Dock = DockStyle.Fill;
            _splash.BackColor = Color.FromArgb(7, 21, 35);
            _splash.BringToFront();

            TableLayoutPanel table = new TableLayoutPanel();
            table.Dock = DockStyle.Fill;
            table.ColumnCount = 1;
            table.RowCount = 4;
            table.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
            table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            table.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));

            _splashTitle = new Label();
            _splashTitle.Text = "千千静听";
            _splashTitle.Font = new Font("Microsoft YaHei UI", 28f, FontStyle.Regular, GraphicsUnit.Point);
            _splashTitle.ForeColor = Color.FromArgb(224, 249, 255);
            _splashTitle.TextAlign = ContentAlignment.MiddleCenter;
            _splashTitle.AutoSize = true;
            _splashTitle.Dock = DockStyle.Fill;
            _splashTitle.Margin = new Padding(0, 0, 0, 4);

            _splashSub = new Label();
            _splashSub.Text = "CLASSIC 5.0   ·   正在准备你的唱片…";
            _splashSub.Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Regular, GraphicsUnit.Point);
            _splashSub.ForeColor = Color.FromArgb(92, 137, 147);
            _splashSub.TextAlign = ContentAlignment.MiddleCenter;
            _splashSub.AutoSize = true;
            _splashSub.Dock = DockStyle.Fill;
            _splashSub.Margin = new Padding(0, 0, 0, 0);

            table.Controls.Add(_splashTitle, 0, 1);
            table.Controls.Add(_splashSub, 0, 2);
            _splash.Controls.Add(table);            Controls.Add(_splash);
        }

        private void BuildWebView()
        {
            _web = new WebView2();
            _web.Dock = DockStyle.Fill;
            _web.AllowExternalDrop = true;
            _web.DefaultBackgroundColor = Color.FromArgb(7, 21, 35);
            _web.Visible = true;
            Controls.Add(_web);
            _web.BringToFront();
            _splash.BringToFront();
        }

        private async void OnPlayerShown(object sender, EventArgs e)
        {
            StartupLog.Write("Form shown");
            try
            {
                _files = LoadPayload();
                StartupLog.Write("payload files: " + _files.Count);
                string profile = ResolveProfileDirectory();
                StartupLog.Write("profile: " + profile);
                _environment = await CoreWebView2Environment.CreateAsync(null, profile, null);
                StartupLog.Write("environment created");
                await _web.EnsureCoreWebView2Async(_environment);
                StartupLog.Write("core ready");
                ConfigureCore();
                _web.CoreWebView2.Navigate(AppHost + "index.html");
                StartupLog.Write("navigate requested");
            }
            catch (Exception error)
            {
                StartupLog.Write("STARTUP ERROR: " + error);
                _splashTitle.Text = "无法启动播放器";
                _splashTitle.Font = new Font("Microsoft YaHei UI", 20f, FontStyle.Regular, GraphicsUnit.Point);
                _splashSub.Text = "请确认系统带有 Microsoft Edge WebView2 运行时。\r\n\r\n" + error.Message;
                _splashSub.ForeColor = Color.FromArgb(220, 153, 136);
                _splashSub.MaximumSize = new Size(720, 0);
                _splashSub.AutoSize = true;
            }
        }

        private static string ResolveProfileDirectory()
        {
            string preferred = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "QianQianClassic",
                "Profile");
            string fallback = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ".data", "profile");
            string[] candidates = new string[] { preferred, fallback };
            Exception lastError = null;
            for (int index = 0; index < candidates.Length; index++)
            {
                try
                {
                    string candidate = candidates[index];
                    Directory.CreateDirectory(candidate);
                    string probe = Path.Combine(candidate, ".write-test");
                    File.WriteAllText(probe, "ok");
                    File.Delete(probe);
                    return candidate;
                }
                catch (Exception error)
                {
                    lastError = error;
                }
            }
            throw new InvalidOperationException("无法创建本地播放器数据目录。", lastError);
        }

        private void ConfigureCore()
        {
            CoreWebView2 core = _web.CoreWebView2;
            core.Settings.AreDefaultContextMenusEnabled = false;
            core.Settings.AreDevToolsEnabled = false;
            core.Settings.IsStatusBarEnabled = false;
            core.Settings.IsZoomControlEnabled = false;
            core.Settings.IsPinchZoomEnabled = false;
            core.Settings.IsSwipeNavigationEnabled = false;
            core.Settings.AreBrowserAcceleratorKeysEnabled = false;
            core.Settings.IsGeneralAutofillEnabled = false;
            core.Settings.IsPasswordAutosaveEnabled = false;
            core.Settings.IsNonClientRegionSupportEnabled = false;

            core.AddWebResourceRequestedFilter(AppHost + "*", CoreWebView2WebResourceContext.All);
            core.WebResourceRequested += OnWebResourceRequested;
            core.NavigationStarting += OnNavigationStarting;
            core.NewWindowRequested += OnNewWindowRequested;
            core.WebMessageReceived += OnWebMessageReceived;
            core.NavigationCompleted += OnNavigationCompleted;
        }

        private static Dictionary<string, byte[]> LoadPayload()
        {
            Dictionary<string, byte[]> files = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("QianQian.web.zip"))
            {
                if (stream == null)
                    throw new InvalidOperationException("播放器资源缺失。");
                using (ZipArchive archive = new ZipArchive(stream, ZipArchiveMode.Read, false, Encoding.UTF8))
                {
                    foreach (ZipArchiveEntry entry in archive.Entries)
                    {
                        if (string.IsNullOrEmpty(entry.Name)) continue;
                        string path = entry.FullName.Replace('\\', '/').TrimStart('/');
                        using (Stream input = entry.Open())
                        using (MemoryStream output = new MemoryStream())
                        {
                            input.CopyTo(output);
                            files[path] = output.ToArray();
                        }
                    }
                }
            }
            if (!files.ContainsKey("index.html"))
                throw new InvalidOperationException("播放器页面资源缺失。");
            return files;
        }

        private void OnNavigationStarting(object sender, CoreWebView2NavigationStartingEventArgs e)
        {
            if (!e.Uri.StartsWith(AppHost, StringComparison.OrdinalIgnoreCase))
                e.Cancel = true;
        }

        private void OnNewWindowRequested(object sender, CoreWebView2NewWindowRequestedEventArgs e)
        {
            e.Handled = true;
        }

        private void OnNavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            if (e.IsSuccess)
            {
                StartupLog.Write("navigation completed");
                _splash.Visible = false;
                PostWindowState();
                StartDebugPolling();
            }
            else
            {
                StartupLog.Write("navigation failed: " + e.WebErrorStatus);
                _splash.Visible = true;
                _splashTitle.Text = "页面加载失败";
                _splashSub.Text = "WebView2 错误代码：" + e.WebErrorStatus;
            }
        }

        private void OnWebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            string json = e.WebMessageAsJson;
            if (string.IsNullOrEmpty(json)) return;
            Match match = Regex.Match(json, "\"action\"\\s*:\\s*\"([^\"]+)\"");
            if (!match.Success) return;
            string action = match.Groups[1].Value;
            if (action == "minimize")
            {
                WindowState = FormWindowState.Minimized;
            }
            else if (action == "toggle-maximize")
            {
                WindowState = WindowState == FormWindowState.Maximized
                    ? FormWindowState.Normal
                    : FormWindowState.Maximized;
                PostWindowState();
            }
            else if (action == "drag")
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, (IntPtr)HTCAPTION, IntPtr.Zero);
            }
            else if (action == "close")
            {
                Close();
            }
            else if (action == "restore")
            {
                if (WindowState == FormWindowState.Minimized)
                    WindowState = FormWindowState.Normal;
                Activate();
            }
        }

        private void PostWindowState()
        {
            if (_web == null || _web.CoreWebView2 == null) return;
            bool maximized = WindowState == FormWindowState.Maximized;
            _lastMaximized = maximized;
            string value = maximized ? "maximized" : "normal";
            _web.CoreWebView2.PostWebMessageAsJson("{\"type\":\"window-state\",\"value\":\"" + value + "\"}");
        }

        private void StartDebugPolling()
        {
            if (Environment.GetEnvironmentVariable("QIANQIAN_DEBUG") != "1") return;
            _debugTimer = new Timer();
            _debugTimer.Interval = 1200;
            _debugTimer.Tick += async delegate
            {
                try
                {
                    string script = "(function(){var a=document.getElementById('audio');return JSON.stringify({paused:a.paused,current:a.currentTime,duration:a.duration,ready:a.readyState,error:a.error?a.error.code:null,status:document.getElementById('status-text').textContent,now:document.getElementById('now-state').textContent,cls:document.body.className,fill:document.getElementById('seek-fill').style.width,total:document.getElementById('time-total').textContent});})()";
                    string result = await _web.ExecuteScriptAsync(script);
                    StartupLog.Write("DEBUG " + result);
                }
                catch (Exception error)
                {
                    StartupLog.Write("DEBUG ERROR " + error.Message);
                }
                _debugTicks += 1;
                if (_debugTicks >= 8 && _debugTimer != null)
                {
                    _debugTimer.Stop();
                }
            };
            _debugTimer.Start();
        }

        private void OnPlayerResize(object sender, EventArgs e)
        {
            bool maximized = WindowState == FormWindowState.Maximized;
            if (maximized != _lastMaximized)
                PostWindowState();
        }

        private void OnWebResourceRequested(object sender, CoreWebView2WebResourceRequestedEventArgs e)
        {
            try
            {
                Uri uri = new Uri(e.Request.Uri);
                string path = Uri.UnescapeDataString(uri.AbsolutePath).TrimStart('/');
                if (string.IsNullOrEmpty(path)) path = "index.html";
                if (!_files.ContainsKey(path))
                {
                    using (MemoryStream missing = new MemoryStream(Encoding.UTF8.GetBytes("Not found")))
                    {
                        e.Response = _environment.CreateWebResourceResponse(
                            missing,
                            404,
                            "Not Found",
                            "Content-Type: text/plain; charset=utf-8\r\nCache-Control: no-store\r\n");
                    }
                    return;
                }

                byte[] data = _files[path];
                long start = 0;
                long end = data.Length - 1;
                int status = 200;
                string reason = "OK";
                string rangeHeader = null;
                try
                {
                    if (e.Request.Headers.Contains("Range"))
                        rangeHeader = e.Request.Headers.GetHeader("Range");
                }
                catch
                {
                    rangeHeader = null;
                }

                if (!string.IsNullOrEmpty(rangeHeader))
                {
                    Match range = Regex.Match(rangeHeader, "bytes\\s*=\\s*(\\d*)\\s*-\\s*(\\d*)");
                    if (range.Success)
                    {
                        if (range.Groups[1].Value.Length == 0 && range.Groups[2].Value.Length > 0)
                        {
                            long suffix = 0;
                            long.TryParse(range.Groups[2].Value, out suffix);
                            if (suffix > 0)
                            {
                                start = Math.Max(0, data.Length - suffix);
                                status = 206;
                                reason = "Partial Content";
                            }
                        }
                        else
                        {
                            long.TryParse(range.Groups[1].Value, out start);
                            if (range.Groups[2].Value.Length > 0)
                                long.TryParse(range.Groups[2].Value, out end);
                            if (start >= 0 && start < data.Length)
                            {
                                status = 206;
                                reason = "Partial Content";
                            }
                        }
                    }
                }

                if (start < 0) start = 0;
                if (end >= data.Length) end = data.Length - 1;
                if (end < start) end = data.Length - 1;
                int length = (int)(end - start + 1);
                if (length < 0) length = 0;

                MemoryStream body = new MemoryStream();
                if (length > 0)
                    body.Write(data, (int)start, length);
                body.Position = 0;

                StringBuilder headers = new StringBuilder();
                headers.Append("Content-Type: ").Append(GetMimeType(path)).Append("\r\n");
                headers.Append("Content-Length: ").Append(length).Append("\r\n");
                headers.Append("Accept-Ranges: bytes\r\n");
                headers.Append("Cache-Control: no-cache, no-store\r\n");
                headers.Append("Access-Control-Allow-Origin: *\r\n");
                headers.Append("Cross-Origin-Resource-Policy: cross-origin\r\n");
                if (status == 206)
                {
                    headers.Append("Content-Range: bytes ")
                        .Append(start).Append("-").Append(end).Append("/")
                        .Append(data.Length).Append("\r\n");
                }
                e.Response = _environment.CreateWebResourceResponse(body, status, reason, headers.ToString());
            }
            catch
            {
                // Let WebView2 present its own network error if anything unexpected happens.
            }
        }

        private static string GetMimeType(string path)
        {
            string extension = Path.GetExtension(path).ToLowerInvariant();
            switch (extension)
            {
                case ".html": return "text/html; charset=utf-8";
                case ".css": return "text/css; charset=utf-8";
                case ".js": return "application/javascript; charset=utf-8";
                case ".svg": return "image/svg+xml";
                case ".png": return "image/png";
                case ".jpg":
                case ".jpeg": return "image/jpeg";
                case ".ico": return "image/x-icon";
                case ".wav": return "audio/wav";
                case ".mp3": return "audio/mpeg";
                case ".lrc": return "text/plain; charset=utf-8";
                case ".json": return "application/json; charset=utf-8";
                default: return "application/octet-stream";
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_NCHITTEST && WindowState == FormWindowState.Normal)
            {
                long value = m.LParam.ToInt64();
                int screenX = (short)(value & 0xFFFF);
                int screenY = (short)((value >> 16) & 0xFFFF);
                Point point = PointToClient(new Point(screenX, screenY));
                int border = 7;
                bool left = point.X <= border;
                bool right = point.X >= ClientSize.Width - border;
                bool top = point.Y <= border;
                bool bottom = point.Y >= ClientSize.Height - border;

                if (top && left) { m.Result = (IntPtr)HTTOPLEFT; return; }
                if (top && right) { m.Result = (IntPtr)HTTOPRIGHT; return; }
                if (bottom && left) { m.Result = (IntPtr)HTBOTTOMLEFT; return; }
                if (bottom && right) { m.Result = (IntPtr)HTBOTTOMRIGHT; return; }
                if (left) { m.Result = (IntPtr)HTLEFT; return; }
                if (right) { m.Result = (IntPtr)HTRIGHT; return; }
                if (top) { m.Result = (IntPtr)HTTOP; return; }
                if (bottom) { m.Result = (IntPtr)HTBOTTOM; return; }
            }
            base.WndProc(ref m);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try
            {
                if (_web != null)
                {
                    _web.Dispose();
                    _web = null;
                }
            }
            catch
            {
                // Let the process exit.
            }
            base.OnFormClosing(e);
        }
    }
}
