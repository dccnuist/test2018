/* =========================================================
   千千静听 · CLASSIC 5.0
   Local-only music player. No network, no upload, no tracking.
   ========================================================= */
(function () {
  'use strict';

  var SETTINGS_KEY = 'qianqian.classic.settings.v1';
  var VISITED_KEY = 'qianqian.classic.visited.v1';
  var nativeBridge = window.chrome && window.chrome.webview && typeof window.chrome.webview.postMessage === 'function'
    ? window.chrome.webview
    : null;
  var AUDIO_EXTENSIONS = ['mp3', 'flac', 'wav', 'ogg', 'oga', 'm4a', 'aac', 'opus', 'webm'];
  var MODES = [
    { id: 'repeat-all', label: '列表循环', icon: 'repeat' },
    { id: 'repeat-one', label: '单曲循环', icon: 'repeat-one' },
    { id: 'shuffle', label: '随机播放', icon: 'shuffle' },
    { id: 'sequence', label: '顺序播放', icon: 'next' }
  ];
  var EQ_FREQUENCIES = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
  var EQ_PRESETS = {
    flat: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    pop: [-1, 0, 1, 2, 3, 3, 2, 1, 0, -1],
    rock: [5, 4, 3, 1, -1, -2, 0, 2, 4, 5],
    classical: [0, 0, 0, 0, -1, -1, -1, -2, -2, -3],
    vocal: [-3, -2, -1, 1, 3, 4, 4, 2, 0, -2],
    bass: [7, 6, 4, 2, 0, 0, 0, 0, 0, 0],
    electronic: [5, 4, 2, 0, -1, 1, 2, 4, 5, 4]
  };
  var DEMO_LRC = [
    '[ti:晚风电台]',
    '[ar:千千静听]',
    '[al:复刻精选 · 2006]',
    '[offset:0]',
    '[00:00.00]晚风把旧唱片轻轻翻开',
    '[00:02.40]城市的灯，一盏一盏慢下来',
    '[00:04.80]耳机里藏着一条回家的路',
    '[00:07.20]绕过夏天，也绕过人海',
    '[00:09.60]如果你也听见远处的潮汐',
    '[00:12.00]那是时间在替我们呼吸',
    '[00:14.40]把今天折成一张小小的信',
    '[00:16.80]寄给很久以前的自己',
    '[00:19.20]夜色温柔，唱针轻轻落下',
    '[00:21.60]所有故事都有了回声',
    '[00:24.00]这一刻不必急着抵达',
    '[00:26.40]让晚风陪我们听完吧',
    '[00:28.80]晚风电台，仍在播放',
    '[00:31.00]下一首，是明天见'
  ].join('\n');

  var $ = function (id) { return document.getElementById(id); };
  var $$ = function (selector, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(selector));
  };

  var el = {
    body: document.body,
    app: $('app-window'),
    audio: $('audio'),
    titlebarTrack: $('titlebar-track'),
    fileInput: $('file-input'),
    folderInput: $('folder-input'),
    lrcInput: $('lrc-input'),
    coverImg: $('cover-img'),
    coverFallback: $('cover-fallback'),
    nowTitle: $('now-title'),
    nowArtist: $('now-artist'),
    nowAlbum: $('now-album'),
    nowState: $('now-state'),
    metaFormat: $('meta-format'),
    metaDuration: $('meta-duration'),
    metaSize: $('meta-size'),
    favoriteBtn: $('btn-favorite'),
    spectrum: $('spectrum'),
    spectrumMeta: $('spectrum-meta'),
    timeCurrent: $('time-current'),
    timeTotal: $('time-total'),
    seek: $('seek'),
    seekArea: document.querySelector('.seek-area'),
    seekFill: $('seek-fill'),
    seekBuffer: $('seek-buffer'),
    seekKnob: $('seek-knob'),
    playBtn: $('btn-play'),
    prevBtn: $('btn-prev'),
    nextBtn: $('btn-next'),
    stopBtn: $('btn-stop'),
    modeBtn: $('btn-mode'),
    modeLabel: $('mode-label'),
    modeIconUse: $('mode-icon-use'),
    muteBtn: $('btn-mute'),
    volume: $('volume'),
    volumeFill: $('volume-fill'),
    volumeValue: $('volume-value'),
    lyricStrip: $('lyric-strip'),
    lyricStripText: $('lyric-strip-text'),
    playlistScroll: $('playlist-scroll'),
    playlistList: $('playlist-list'),
    playlistEmpty: $('playlist-empty'),
    playlistCount: $('playlist-count'),
    playlistSearch: $('playlist-search'),
    tabCount: $('tab-count'),
    removeBtn: $('btn-playlist-remove'),
    clearBtn: $('btn-playlist-clear'),
    tabButtons: $$('.tab-btn'),
    tabPanels: $$('.tab-panel'),
    lyricsScroll: $('lyrics-scroll'),
    lyricsLines: $('lyrics-lines'),
    lyricsEmpty: $('lyrics-empty'),
    lyricsSongTitle: $('lyrics-song-title'),
    lyricsSongMeta: $('lyrics-song-meta'),
    syncState: $('sync-state'),
    offsetValue: $('offset-value'),
    eqEnable: $('eq-enable'),
    eqStatus: $('eq-status'),
    eqPreset: $('eq-preset'),
    eqSliders: $$('.eq-slider'),
    eqGains: $$('.eq-gain'),
    preampValue: $('preamp-value'),
    statusText: $('status-text'),
    statusLed: $('status-led'),
    statusTracks: $('status-tracks'),
    statusFormat: $('status-format'),
    statusClock: $('status-clock'),
    mini: $('mini-player'),
    miniCover: $('mini-cover'),
    miniTitle: $('mini-title'),
    miniArtist: $('mini-artist'),
    miniPlay: $('mini-play'),
    miniPrev: $('mini-prev'),
    miniNext: $('mini-next'),
    miniTime: $('mini-time'),
    miniProgress: $('mini-progress-fill'),
    menuTriggers: $$('.menu-trigger'),
    menuPopovers: $$('.menu-popover'),
    menuPlayText: $('menu-play-text'),
    menuRadios: $$('.menu-radio'),
    dragOverlay: $('drag-overlay'),
    toastContainer: $('toast-container'),
    exitScreen: $('exit-screen'),
    aboutModal: $('modal-about'),
    shortcutsModal: $('modal-shortcuts')
  };

  var state = loadSettings();
  state.tracks = [];
  state.current = -1;
  state.selected = -1;
  state.loadedTrackId = null;
  state.scrubbing = false;
  state.dragDepth = 0;
  state.hydrateQueue = [];
  state.hydrateActive = 0;
  state.lyricActive = -1;
  state.lyricEls = [];
  state.lyricManualUntil = 0;
  state.audioGraphFailed = false;
  state.audioCtx = null;
  state.analyser = null;
  state.frequencyData = null;
  state.filters = [];
  state.spectrumCtx = null;
  state.spectrumLevels = [];
  state.spectrumPeaks = [];
  state.lastProgressPaint = 0;
  state.lastErrorTrack = null;
  state.favorites = loadFavorites();
  state.query = '';

  var objectUrls = new Set();
  var audioSourceNode = null;

  /* =========================================================
     Small helpers
     ========================================================= */
  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function pad2(value) {
    return value < 10 ? '0' + value : String(value);
  }

  function formatTime(seconds) {
    if (!Number.isFinite(seconds) || seconds < 0) return '00:00';
    var whole = Math.floor(seconds);
    var hours = Math.floor(whole / 3600);
    var minutes = Math.floor((whole % 3600) / 60);
    var secs = whole % 60;
    return hours > 0 ? hours + ':' + pad2(minutes) + ':' + pad2(secs) : pad2(minutes) + ':' + pad2(secs);
  }

  function formatBytes(bytes) {
    if (!bytes) return '本地文件';
    if (bytes < 1048576) return Math.max(1, Math.round(bytes / 1024)) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  }

  function formatOffset(seconds) {
    var sign = seconds > 0 ? '+' : seconds < 0 ? '−' : '';
    return sign + Math.abs(seconds).toFixed(1) + 's';
  }

  function stripExt(name) {
    var index = name.lastIndexOf('.');
    return index > 0 ? name.slice(0, index) : name;
  }

  function extOf(name) {
    var index = name.lastIndexOf('.');
    return index >= 0 ? name.slice(index + 1).toLowerCase() : '';
  }

  function normalizePath(path) {
    return String(path || '').replace(/\\/g, '/').replace(/^\/+/, '');
  }

  function isAudio(name) {
    return AUDIO_EXTENSIONS.indexOf(extOf(name)) !== -1;
  }

  function isLrc(name) {
    return extOf(name) === 'lrc';
  }

  function parseFileName(name) {
    var base = stripExt(name).replace(/_/g, ' ').trim();
    base = base.replace(/^\s*\d{1,3}\s*[.、\-_]\s*(?=\S)/, '').trim();
    var artist = '';
    var title = base;
    var spaced = base.split(/\s+[-–—]\s+/);
    if (spaced.length >= 2) {
      artist = spaced.slice(0, -1).join(' - ').trim();
      title = spaced[spaced.length - 1].trim();
    } else {
      var dash = base.lastIndexOf('-');
      if (dash > 0 && dash < base.length - 1) {
        artist = base.slice(0, dash).trim();
        title = base.slice(dash + 1).trim();
      }
    }
    if (!title) title = base || '未命名音频';
    return { title: title, artist: artist };
  }

  function pathFolder(path) {
    var parts = normalizePath(path).split('/');
    if (parts.length < 2) return '';
    return parts[parts.length - 2] || '';
  }

  function basename(path) {
    var parts = normalizePath(path).split('/');
    return parts[parts.length - 1] || '';
  }

  function makeFileKey(file) {
    return [file.name, file.size, file.lastModified || 0].join('|');
  }

  function makeId() {
    return 't' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function debounce(fn, wait) {
    var timer = null;
    return function () {
      var args = arguments;
      var context = this;
      clearTimeout(timer);
      timer = setTimeout(function () { fn.apply(context, args); }, wait);
    };
  }

  function scheduleListRender() {
    if (state.renderTimer) return;
    state.renderTimer = setTimeout(function () {
      state.renderTimer = null;
      renderPlaylist(true);
    }, 80);
  }

  function showToast(message, type) {
    var toast = document.createElement('div');
    toast.className = 'toast' + (type === 'error' ? ' is-error' : '');
    toast.textContent = message;
    el.toastContainer.appendChild(toast);
    while (el.toastContainer.children.length > 3) {
      el.toastContainer.removeChild(el.toastContainer.firstElementChild);
    }
    setTimeout(function () {
      toast.classList.add('is-leaving');
      setTimeout(function () {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 240);
    }, 2800);
  }

  function setStatus(text, kind) {
    el.statusText.textContent = text;
    el.statusLed.classList.remove('is-live', 'is-paused');
    if (kind === 'live') el.statusLed.classList.add('is-live');
    if (kind === 'paused') el.statusLed.classList.add('is-paused');
  }

  function readBlob(blob) {
    if (blob.arrayBuffer) return blob.arrayBuffer();
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () { resolve(reader.result); };
      reader.onerror = function () { reject(reader.error || new Error('无法读取文件')); };
      reader.readAsArrayBuffer(blob);
    });
  }

  async function readTextSmart(file) {
    var buffer = await readBlob(file);
    var bytes = new Uint8Array(buffer);
    var offset = 0;
    if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
      offset = 3;
    }
    var body = bytes.subarray(offset);
    try {
      return new TextDecoder('utf-8', { fatal: true }).decode(body).replace(/^\uFEFF/, '');
    } catch (error) {
      try {
        return new TextDecoder('gbk').decode(body);
      } catch (gbkError) {
        return new TextDecoder('utf-8').decode(body).replace(/^\uFEFF/, '');
      }
    }
  }

  function isFormField(target) {
    if (!target) return false;
    var tag = target.tagName;
    return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || target.isContentEditable;
  }

  /* =========================================================
     Settings
     ========================================================= */
  function defaultSettings() {
    return {
      volume: 0.78,
      muted: false,
      mode: 'repeat-all',
      tab: 'playlist',
      eqEnabled: true,
      eqPreset: 'pop',
      eqBands: EQ_PRESETS.pop.slice()
    };
  }

  function loadSettings() {
    var defaults = defaultSettings();
    var saved = null;
    try {
      saved = JSON.parse(localStorage.getItem(SETTINGS_KEY) || 'null');
    } catch (error) {
      saved = null;
    }
    if (!saved || typeof saved !== 'object') return defaults;
    var result = Object.assign(defaults, saved);
    result.volume = clamp(Number(result.volume) || 0, 0, 1);
    if (!MODES.some(function (mode) { return mode.id === result.mode; })) result.mode = 'repeat-all';
    if (['playlist', 'lyrics', 'eq'].indexOf(result.tab) === -1) result.tab = 'playlist';
    result.eqEnabled = result.eqEnabled !== false;
    if (!Array.isArray(result.eqBands) || result.eqBands.length !== 10) {
      result.eqBands = (EQ_PRESETS[result.eqPreset] || EQ_PRESETS.pop).slice();
    } else {
      result.eqBands = result.eqBands.map(function (value) { return clamp(Number(value) || 0, -12, 12); });
    }
    if (!EQ_PRESETS[result.eqPreset] && result.eqPreset !== 'custom') result.eqPreset = 'pop';
    return result;
  }

  var saveSettings = debounce(function () {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify({
        volume: state.volume,
        muted: state.muted,
        mode: state.mode,
        tab: state.tab,
        eqEnabled: state.eqEnabled,
        eqPreset: state.eqPreset,
        eqBands: state.eqBands
      }));
    } catch (error) {
      // Private mode or storage is unavailable; the player still works.
    }
  }, 180);

  function loadFavorites() {
    try {
      var list = JSON.parse(localStorage.getItem('qianqian.classic.favorites.v1') || '[]');
      return Array.isArray(list) ? list : [];
    } catch (error) {
      return [];
    }
  }

  function saveFavorites() {
    try {
      localStorage.setItem('qianqian.classic.favorites.v1', JSON.stringify(state.favorites));
    } catch (error) {
      // Ignore storage failures.
    }
  }

  /* =========================================================
     Demo track and track creation
     ========================================================= */
  function createDemoTrack() {
    var base = window.location.href;
    return {
      id: 'demo-night-breeze',
      key: 'demo:night-breeze',
      fileName: '晚风电台.wav',
      path: 'demo/晚风电台.wav',
      ext: 'WAV',
      isDemo: true,
      file: null,
      url: new URL('demo/晚风电台.wav', base).href,
      coverUrl: new URL('assets/demo-cover.svg', base).href,
      title: '晚风电台',
      artist: '千千静听',
      album: '复刻精选 · 2006',
      duration: 32,
      size: 2048044,
      lrcText: DEMO_LRC,
      lrcSource: '内置同步歌词',
      lyrics: null,
      lyricOffset: 0,
      hydrated: true,
      addedAt: Date.now()
    };
  }

  function createFileTrack(source, lrcFile) {
    var file = source.file;
    var path = normalizePath(source.path || file.webkitRelativePath || file.relativePath || file.name);
    var parsed = parseFileName(file.name);
    var folder = pathFolder(path);
    return {
      id: makeId(),
      key: makeFileKey(file),
      fileName: file.name,
      path: path,
      ext: extOf(file.name).toUpperCase(),
      isDemo: false,
      file: file,
      url: URL.createObjectURL(file),
      coverUrl: null,
      title: parsed.title,
      artist: parsed.artist,
      album: folder || '本地音乐',
      duration: 0,
      size: file.size,
      lrcFile: lrcFile || null,
      lrcText: null,
      lrcSource: '',
      lyrics: null,
      lyricOffset: 0,
      hydrated: false,
      addedAt: Date.now()
    };
  }

  function currentTrack() {
    return state.tracks[state.current] || null;
  }

  function isFavorite(track) {
    return !!track && state.favorites.indexOf(track.key) !== -1;
  }

  /* =========================================================
     Audio graph / equalizer
     ========================================================= */
  function ensureAudioGraph() {
    if (state.audioCtx || state.audioGraphFailed) return;
    var AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) {
      state.audioGraphFailed = true;
      return;
    }
    try {
      var context = new AudioCtx();
      var source = context.createMediaElementSource(el.audio);
      var analyser = context.createAnalyser();
      analyser.fftSize = 1024;
      analyser.smoothingTimeConstant = 0.82;
      var preamp = context.createGain();
      preamp.gain.value = 1;
      var filters = EQ_FREQUENCIES.map(function (frequency) {
        var filter = context.createBiquadFilter();
        filter.type = 'peaking';
        filter.frequency.value = frequency;
        filter.Q.value = 1.05;
        filter.gain.value = 0;
        return filter;
      });
      var node = source;
      filters.forEach(function (filter) {
        node.connect(filter);
        node = filter;
      });
      node.connect(preamp);
      preamp.connect(analyser);
      analyser.connect(context.destination);

      state.audioCtx = context;
      state.analyser = analyser;
      state.filters = filters;
      state.preamp = preamp;
      state.frequencyData = new Uint8Array(analyser.frequencyBinCount);
      audioSourceNode = source;
      applyEQ();
    } catch (error) {
      state.audioGraphFailed = true;
      if (audioSourceNode) {
        try { audioSourceNode.connect(state.audioCtx.destination); } catch (connectError) { /* silence */ }
      }
    }
  }

  function applyEQ() {
    if (!state.filters.length) return;
    state.filters.forEach(function (filter, index) {
      filter.gain.value = state.eqEnabled ? Number(state.eqBands[index] || 0) : 0;
    });
  }

  function setEqEnabled(enabled, notify) {
    state.eqEnabled = !!enabled;
    el.eqEnable.setAttribute('aria-checked', state.eqEnabled ? 'true' : 'false');
    el.eqStatus.textContent = state.eqEnabled ? '已启用' : '已关闭';
    applyEQ();
    saveSettings();
    if (notify) showToast(state.eqEnabled ? '均衡器已启用' : '均衡器已关闭');
  }

  function setEqPreset(preset) {
    state.eqPreset = preset;
    el.eqPreset.value = preset;
    if (EQ_PRESETS[preset]) {
      state.eqBands = EQ_PRESETS[preset].slice();
      state.eqBands.forEach(function (value, index) {
        if (el.eqSliders[index]) el.eqSliders[index].value = String(value);
      });
      paintEqValues();
      applyEQ();
      saveSettings();
    }
  }

  function paintEqValues() {
    el.eqSliders.forEach(function (slider, index) {
      var value = Number(slider.value) || 0;
      var label = el.eqGains[index];
      if (!label) return;
      label.textContent = value > 0 ? '+' + value : String(value);
      label.classList.toggle('is-boost', value > 0);
      label.classList.toggle('is-cut', value < 0);
      var percent = (value + 12) / 24 * 100;
      var track = slider;
      track.style.setProperty('--eq-percent', percent.toFixed(1) + '%');
    });
    if (el.preampValue) el.preampValue.textContent = '0.0 dB';
  }

  function matchPreset(values) {
    var keys = Object.keys(EQ_PRESETS);
    for (var i = 0; i < keys.length; i++) {
      var preset = EQ_PRESETS[keys[i]];
      var same = preset.every(function (value, index) { return Number(value) === Number(values[index]); });
      if (same) return keys[i];
    }
    return 'custom';
  }

  /* =========================================================
     Rendering: player info
     ========================================================= */
  function renderCurrentInfo() {
    var track = currentTrack();
    if (!track) {
      el.nowTitle.textContent = '未选择歌曲';
      el.nowArtist.textContent = '从本地添加你的音乐';
      el.nowAlbum.textContent = '支持 MP3 / FLAC / WAV / M4A / OGG';
      el.metaFormat.textContent = '—';
      el.metaDuration.textContent = '00:00';
      el.metaSize.textContent = '本地音源';
      el.titlebarTrack.textContent = '本地音乐，随时开场';
      el.coverImg.hidden = true;
      el.coverFallback.hidden = false;
      el.favoriteBtn.classList.remove('is-liked');
      el.favoriteBtn.setAttribute('aria-pressed', 'false');
      el.statusFormat.textContent = '本地音乐';
      el.lyricsSongTitle.textContent = '未选择歌曲';
      el.lyricsSongMeta.textContent = '添加一首歌，再导入它的 LRC 歌词';
      el.lyricStrip.classList.remove('is-live');
      el.lyricStripText.textContent = '暂无同步歌词 · 可在歌词页导入 LRC 文件';
      document.title = '千千静听 · 本地音乐播放器';
      updateMini();
      updateMediaSession();
      renderLyrics();
      return;
    }

    el.nowTitle.textContent = track.title || '未命名音频';
    el.nowTitle.title = track.title || '';
    el.nowArtist.textContent = track.artist || '未知歌手';
    el.nowAlbum.textContent = track.album || pathFolder(track.path) || '本地音乐';
    el.metaFormat.textContent = track.ext || extOf(track.fileName).toUpperCase() || 'AUDIO';
    el.metaDuration.textContent = formatTime(getDuration());
    el.metaSize.textContent = track.isDemo ? '内置示例' : formatBytes(track.size);
    el.titlebarTrack.textContent = track.title + '  ·  ' + (track.artist || '未知歌手');
    el.statusFormat.textContent = (track.ext || 'AUDIO') + ' · 本地';
    el.lyricsSongTitle.textContent = track.title || '未命名音频';
    el.lyricsSongMeta.textContent = (track.artist || '未知歌手') + ' · ' + (track.album || '本地音乐');
    document.title = (track.title || '千千静听') + ' - 千千静听';

    if (track.coverUrl) {
      el.coverImg.src = track.coverUrl;
      el.coverImg.hidden = false;
      el.coverFallback.hidden = true;
    } else {
      el.coverImg.hidden = true;
      el.coverImg.removeAttribute('src');
      el.coverFallback.hidden = false;
    }

    var favorite = isFavorite(track);
    el.favoriteBtn.classList.toggle('is-liked', favorite);
    el.favoriteBtn.setAttribute('aria-pressed', favorite ? 'true' : 'false');
    el.favoriteBtn.querySelector('span').textContent = favorite ? '已收藏' : '收藏';

    updateMini();
    updateMediaSession();
  }

  function getDuration() {
    var track = currentTrack();
    if (Number.isFinite(el.audio.duration) && el.audio.duration > 0) return el.audio.duration;
    if (track && Number.isFinite(track.duration) && track.duration > 0) return track.duration;
    return 0;
  }

  function renderProgress(forceTime) {
    var duration = getDuration();
    var current = Number.isFinite(el.audio.currentTime) ? el.audio.currentTime : 0;
    if (forceTime !== undefined) current = forceTime;
    var percent = duration > 0 ? clamp(current / duration, 0, 1) : 0;
    var percentText = (percent * 100).toFixed(2) + '%';
    el.seekFill.style.width = percentText;
    el.seekKnob.style.left = percentText;
    if (!state.scrubbing) el.seek.value = String(Math.round(percent * 1000));
    el.timeCurrent.textContent = formatTime(current);
    el.timeTotal.textContent = formatTime(duration);
    if (el.audio.buffered && el.audio.buffered.length && duration > 0) {
      var bufferedEnd = el.audio.buffered.end(el.audio.buffered.length - 1);
      el.seekBuffer.style.width = clamp(bufferedEnd / duration, 0, 1) * 100 + '%';
    }
    el.miniProgress.style.width = percentText;
    el.miniTime.textContent = formatTime(current) + ' / ' + formatTime(duration);
    if (!state.scrubbing) {
      el.seekFill.style.width = percentText;
    }
  }

  function resetProgress(duration) {
    el.seek.value = '0';
    el.seekFill.style.width = '0%';
    el.seekBuffer.style.width = '0%';
    el.seekKnob.style.left = '0%';
    el.timeCurrent.textContent = '00:00';
    el.timeTotal.textContent = formatTime(duration || 0);
    el.miniProgress.style.width = '0%';
    el.miniTime.textContent = '00:00 / ' + formatTime(duration || 0);
    el.metaDuration.textContent = formatTime(duration || 0);
  }

  function updateMini() {
    var track = currentTrack();
    if (!track) {
      el.miniTitle.textContent = '未选择歌曲';
      el.miniArtist.textContent = '千千静听';
      el.miniCover.removeAttribute('src');
      return;
    }
    el.miniTitle.textContent = track.title || '未命名音频';
    el.miniArtist.textContent = track.artist || '未知歌手';
    el.miniCover.src = track.coverUrl || new URL('assets/demo-cover.svg', window.location.href).href;
    el.miniPlay.setAttribute('aria-label', el.audio.paused ? '播放' : '暂停');
  }

  function setFavoriteState() {
    var track = currentTrack();
    if (!track) return;
    var index = state.favorites.indexOf(track.key);
    if (index === -1) {
      state.favorites.push(track.key);
      showToast('已收藏：' + track.title);
    } else {
      state.favorites.splice(index, 1);
      showToast('已取消收藏');
    }
    saveFavorites();
    renderCurrentInfo();
    renderPlaylist(true);
  }

  /* =========================================================
     Playback
     ========================================================= */
  async function resumeAudioContext() {
    if (!state.audioCtx) return;
    try {
      if (state.audioCtx.state === 'suspended') await state.audioCtx.resume();
    } catch (error) {
      // Playback still works even if the context could not resume.
    }
  }

  function playAudio() {
    var track = currentTrack();
    if (!track) {
      if (state.tracks.length) {
        loadTrack(0, true);
      } else {
        showToast('先添加一些本地音乐吧');
        el.fileInput.click();
      }
      return;
    }
    if (state.loadedTrackId !== track.id) {
      loadTrack(state.current, true);
      return;
    }
    ensureAudioGraph();
    resumeAudioContext();
    if (el.audio.readyState === 0 && !el.audio.src) {
      el.audio.src = track.url;
    }
    var promise = el.audio.play();
    if (promise && promise.catch) {
      promise.catch(function (error) {
        if (error && error.name === 'NotAllowedError') {
          showToast('浏览器阻止了自动播放，请再点一次播放键', 'error');
        } else if (error && error.name === 'NotSupportedError') {
          showToast('这个音频格式暂时无法播放：' + track.ext, 'error');
        } else if (error && error.name !== 'AbortError') {
          showToast('播放失败：' + (error.message || '未知错误'), 'error');
        }
        state.playing = false;
        syncPlayingState();
      });
    }
  }

  function pauseAudio() {
    el.audio.pause();
  }

  function togglePlay() {
    if (!currentTrack()) {
      if (state.tracks.length) loadTrack(0, true);
      else {
        showToast('先添加一些本地音乐吧');
        el.fileInput.click();
      }
      return;
    }
    if (el.audio.paused) {
      if (el.audio.ended) el.audio.currentTime = 0;
      playAudio();
    } else {
      pauseAudio();
    }
  }

  function stopPlayback() {
    if (!currentTrack()) return;
    el.audio.pause();
    try { el.audio.currentTime = 0; } catch (error) { /* not seekable yet */ }
    state.playing = false;
    syncPlayingState();
    renderProgress(0);
    updateLyrics(true);
    setStatus('已停止');
  }

  function syncPlayingState() {
    var playing = !el.audio.paused && !el.audio.ended;
    state.playing = playing;
    el.body.classList.toggle('is-playing', playing);
    el.playBtn.setAttribute('aria-label', playing ? '暂停' : '播放');
    el.playBtn.title = playing ? '暂停 (Space)' : '播放 (Space)';
    el.menuPlayText.textContent = playing ? '暂停' : '播放';
    el.windowState = playing ? 'playing' : 'paused';
    if (playing) {
      setStatus('正在播放', 'live');
      el.nowState.textContent = '正在播放';
    } else if (!el.audio.ended && el.audio.currentTime > 0 && currentTrack()) {
      setStatus('已暂停', 'paused');
      el.nowState.textContent = '已暂停';
    } else if (currentTrack()) {
      setStatus('已就绪');
      el.nowState.textContent = '准备就绪';
    }
    updateMini();
    updateMediaSession();
    updateLyricStripState();
  }

  function loadTrack(index, autoplay) {
    var track = state.tracks[index];
    if (!track) return;
    var changed = state.loadedTrackId !== track.id || state.current !== index;
    state.current = index;
    state.selected = index;
    state.lastErrorTrack = null;
    state.lyricActive = -1;
    state.lyricManualUntil = 0;

    if (changed) {
      state.loadedTrackId = track.id;
      el.audio.pause();
      try {
        el.audio.src = track.url;
        el.audio.load();
      } catch (error) {
        showToast('无法加载音频文件', 'error');
      }
      resetProgress(track.duration);
      ensureLyrics(track);
      renderLyrics();
      renderProgress(0);
      setStatus('正在读取…');
      el.nowState.textContent = '正在读取…';
    }

    renderCurrentInfo();
    renderPlaylist(true);
    updateLyrics(true);
    if (autoplay) playAudio();
  }

  function nextTrack(manual) {
    if (!state.tracks.length) return;
    var index = state.current;
    var next = -1;
    if (state.mode === 'shuffle' && state.tracks.length > 1) {
      do {
        next = Math.floor(Math.random() * state.tracks.length);
      } while (next === index);
    } else {
      next = index + 1;
      if (next >= state.tracks.length) {
        if (state.mode === 'repeat-all' || manual) next = 0;
        else {
          stopAtEnd();
          return;
        }
      }
    }
    if (next >= 0) loadTrack(next, true);
  }

  function previousTrack() {
    if (!state.tracks.length) return;
    if (el.audio.currentTime > 3) {
      el.audio.currentTime = 0;
      renderProgress(0);
      return;
    }
    var previous = state.current - 1;
    if (previous < 0) previous = state.tracks.length - 1;
    loadTrack(previous, true);
  }

  function stopAtEnd() {
    el.audio.pause();
    state.playing = false;
    syncPlayingState();
    setStatus('播放结束');
    el.nowState.textContent = '播放结束';
  }

  function handleEnded() {
    if (!currentTrack()) return;
    if (state.mode === 'repeat-one') {
      el.audio.currentTime = 0;
      playAudio();
      return;
    }
    var atEnd = state.current >= state.tracks.length - 1;
    if (atEnd && state.mode === 'sequence') {
      stopAtEnd();
      return;
    }
    nextTrack(false);
  }

  function setMode(mode) {
    if (!MODES.some(function (item) { return item.id === mode; })) return;
    state.mode = mode;
    var info = MODES.filter(function (item) { return item.id === mode; })[0];
    el.modeLabel.textContent = info.label;
    el.modeIconUse.setAttribute('href', '#i-' + info.icon);
    el.modeBtn.title = '播放模式：' + info.label;
    el.menuRadios.forEach(function (item) {
      item.classList.toggle('is-checked', item.getAttribute('data-mode') === mode);
    });
    saveSettings();
  }

  function cycleMode() {
    var index = MODES.map(function (item) { return item.id; }).indexOf(state.mode);
    setMode(MODES[(index + 1) % MODES.length].id);
    showToast('播放模式：' + MODES[(index + 1) % MODES.length].label);
  }

  /* =========================================================
     Progress / volume / mute
     ========================================================= */
  function bindProgress() {
    el.audio.addEventListener('timeupdate', function () {
      if (!state.scrubbing) renderProgress();
      updateLyrics(false);
    });
    el.audio.addEventListener('loadedmetadata', function () {
      var track = currentTrack();
      var duration = Number.isFinite(el.audio.duration) ? el.audio.duration : 0;
      if (track && duration > 0) track.duration = duration;
      el.metaDuration.textContent = formatTime(duration || (track ? track.duration : 0));
      renderProgress();
      renderPlaylist(true);
    });
    el.audio.addEventListener('durationchange', function () {
      var track = currentTrack();
      var duration = Number.isFinite(el.audio.duration) ? el.audio.duration : 0;
      if (track && duration > 0) track.duration = duration;
      if (!el.audio.paused) el.timeTotal.textContent = formatTime(duration || 0);
    });
    el.audio.addEventListener('progress', function () {
      var duration = getDuration();
      if (!duration || !el.audio.buffered.length) return;
      var bufferedEnd = el.audio.buffered.end(el.audio.buffered.length - 1);
      el.seekBuffer.style.width = clamp(bufferedEnd / duration, 0, 1) * 100 + '%';
    });
    el.audio.addEventListener('play', function () {
      ensureAudioGraph();
      resumeAudioContext();
      el.nowState.textContent = '正在播放';
      syncPlayingState();
    });
    el.audio.addEventListener('playing', function () {
      state.buffering = false;
      el.body.classList.remove('is-buffering');
      syncPlayingState();
    });
    el.audio.addEventListener('pause', function () {
      if (!el.audio.ended) {
        state.buffering = false;
        el.body.classList.remove('is-buffering');
      }
      syncPlayingState();
    });
    el.audio.addEventListener('waiting', function () {
      state.buffering = true;
      el.body.classList.add('is-buffering');
      if (state.playing) setStatus('缓冲中…', 'live');
    });
    el.audio.addEventListener('canplay', function () {
      state.buffering = false;
      el.body.classList.remove('is-buffering');
    });
    el.audio.addEventListener('ended', handleEnded);
    el.audio.addEventListener('error', function () {
      var track = currentTrack();
      if (!track || state.lastErrorTrack === track.id) return;
      if (!el.audio.currentSrc && !el.audio.src) return;
      state.lastErrorTrack = track.id;
      state.playing = false;
      syncPlayingState();
      setStatus('无法播放这个文件');
      el.nowState.textContent = '无法播放';
      showToast('无法播放「' + track.title + '」，浏览器可能不支持这个音频格式', 'error');
    });

    el.seek.addEventListener('pointerdown', function () {
      state.scrubbing = true;
      el.seekArea.classList.add('is-scrubbing');
    });
    el.seek.addEventListener('input', function () {
      var duration = getDuration();
      if (!duration) return;
      state.scrubbing = true;
      var value = Number(el.seek.value) / 1000;
      var target = value * duration;
      var percent = (value * 100).toFixed(2) + '%';
      el.seekFill.style.width = percent;
      el.seekKnob.style.left = percent;
      el.timeCurrent.textContent = formatTime(target);
      if (el.audio.readyState > 0) {
        try { el.audio.currentTime = target; } catch (error) { /* ignore */ }
      }
      updateLyrics(true);
    });
    var endScrub = function () {
      state.scrubbing = false;
      el.seekArea.classList.remove('is-scrubbing');
      renderProgress();
    };
    el.seek.addEventListener('change', endScrub);
    el.seek.addEventListener('pointerup', endScrub);
    el.seek.addEventListener('blur', function () {
      if (state.scrubbing) endScrub();
    });

    el.volume.value = String(Math.round(state.volume * 100));
    updateVolumeUI();
    el.volume.addEventListener('input', function () {
      state.volume = clamp(Number(el.volume.value) / 100, 0, 1);
      state.muted = false;
      el.audio.muted = false;
      el.audio.volume = state.volume;
      updateVolumeUI();
      saveSettings();
    });
    el.muteBtn.addEventListener('click', toggleMute);
  }

  function toggleMute() {
    state.muted = !state.muted;
    el.audio.muted = state.muted;
    updateVolumeUI();
    saveSettings();
  }

  function updateVolumeUI() {
    var value = Math.round(state.volume * 100);
    el.volume.value = String(value);
    el.volumeFill.style.width = value + '%';
    el.volumeValue.textContent = String(value);
    el.body.classList.toggle('is-muted', state.muted);
    el.muteBtn.setAttribute('aria-label', state.muted ? '取消静音' : '静音');
    el.muteBtn.title = state.muted ? '取消静音 (M)' : '静音 (M)';
    el.audio.volume = state.volume;
    el.audio.muted = state.muted;
  }

  function changeVolume(delta) {
    state.volume = clamp(state.volume + delta, 0, 1);
    if (state.muted && state.volume > 0) {
      state.muted = false;
      el.audio.muted = false;
    }
    updateVolumeUI();
    saveSettings();
  }

  function seekBy(seconds) {
    var duration = getDuration();
    if (!duration) return;
    el.audio.currentTime = clamp(el.audio.currentTime + seconds, 0, duration);
    renderProgress();
    updateLyrics(true);
  }

  /* =========================================================
     Playlist
     ========================================================= */
  function getFilteredTracks() {
    var query = state.query.trim().toLowerCase();
    if (!query) {
      return state.tracks.map(function (track, index) { return { track: track, index: index }; });
    }
    return state.tracks.map(function (track, index) {
      return { track: track, index: index };
    }).filter(function (item) {
      var track = item.track;
      return [track.title, track.artist, track.album, track.fileName].join(' ').toLowerCase().indexOf(query) !== -1;
    });
  }

  function renderPlaylist(preserveScroll) {
    var scrollTop = el.playlistScroll.scrollTop;
    var filtered = getFilteredTracks();
    var fragment = document.createDocumentFragment();
    el.playlistList.textContent = '';

    filtered.forEach(function (item) {
      fragment.appendChild(createTrackRow(item.track, item.index));
    });

    if (filtered.length === 0 && state.tracks.length > 0) {
      var noResults = document.createElement('div');
      noResults.className = 'playlist-no-results';
      noResults.innerHTML = '<b>没有找到匹配的歌曲</b><span>换一个关键词试试</span>';
      fragment.appendChild(noResults);
    }

    el.playlistList.appendChild(fragment);

    var trackCount = state.tracks.length;
    var filteredCount = filtered.length;
    el.playlistCount.textContent = state.query.trim() ? filteredCount + ' / ' + trackCount + ' 首' : trackCount + ' 首';
    el.tabCount.textContent = String(trackCount);
    el.statusTracks.textContent = trackCount + ' 首';
    el.playlistEmpty.hidden = trackCount !== 0;
    el.playlistList.hidden = trackCount === 0;
    el.removeBtn.disabled = state.selected < 0 && state.current < 0;
    el.clearBtn.disabled = trackCount === 0;
    if (preserveScroll) el.playlistScroll.scrollTop = scrollTop;
    updatePlaybackRowState();
  }

  function createTrackRow(track, index) {
    var row = document.createElement('div');
    row.className = 'track-row';
    if (index === state.current) row.classList.add('is-active');
    if (index === state.selected) row.classList.add('is-selected');
    row.dataset.index = String(index);
    row.setAttribute('role', 'option');
    row.setAttribute('aria-selected', index === state.selected ? 'true' : 'false');
    row.draggable = true;
    row.title = (track.title || '未命名') + ' · ' + (track.artist || '未知歌手') + '（双击播放）';

    var number = document.createElement('div');
    number.className = 'track-no';
    var numberText = document.createElement('span');
    numberText.textContent = String(index + 1).padStart(2, '0');
    var wave = document.createElement('span');
    wave.className = 'track-wave';
    wave.innerHTML = '<i></i><i></i><i></i>';
    number.appendChild(numberText);
    number.appendChild(wave);

    var main = document.createElement('div');
    main.className = 'track-main';
    var name = document.createElement('div');
    name.className = 'track-name';
    var nameText = document.createElement('span');
    nameText.className = 'track-name-text';
    nameText.textContent = track.title || track.fileName;
    name.appendChild(nameText);
    if (track.isDemo) {
      var badge = document.createElement('span');
      badge.className = 'track-badge';
      badge.textContent = 'DEMO';
      name.appendChild(badge);
    } else if (track.lrcFile || track.lrcText) {
      var lrcBadge = document.createElement('span');
      lrcBadge.className = 'track-badge track-badge-lrc';
      lrcBadge.textContent = 'LRC';
      name.appendChild(lrcBadge);
    }
    var sub = document.createElement('div');
    sub.className = 'track-sub';
    var subText = [track.artist || '未知歌手'];
    if (track.album) subText.push(track.album);
    sub.textContent = subText.join(' · ');
    main.appendChild(name);
    main.appendChild(sub);

    var duration = document.createElement('div');
    duration.className = 'track-duration';
    duration.textContent = track.duration > 0 ? formatTime(track.duration) : '—:—';

    row.appendChild(number);
    row.appendChild(main);
    row.appendChild(duration);
    return row;
  }

  function updatePlaybackRowState() {
    $$('.track-row', el.playlistList).forEach(function (row) {
      var index = Number(row.dataset.index);
      row.classList.toggle('is-active', index === state.current);
      row.classList.toggle('is-selected', index === state.selected);
      row.setAttribute('aria-selected', index === state.selected ? 'true' : 'false');
    });
  }

  function bindPlaylist() {
    el.playlistSearch.addEventListener('input', function () {
      state.query = el.playlistSearch.value;
      renderPlaylist(false);
    });
    el.playlistSearch.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        el.playlistSearch.value = '';
        state.query = '';
        renderPlaylist(false);
        el.playlistSearch.blur();
      }
    });

    el.playlistList.addEventListener('click', function (event) {
      var row = event.target.closest('.track-row');
      if (!row) return;
      state.selected = Number(row.dataset.index);
      renderPlaylist(true);
    });

    el.playlistList.addEventListener('dblclick', function (event) {
      var row = event.target.closest('.track-row');
      if (!row) return;
      var index = Number(row.dataset.index);
      if (state.current === index && state.loadedTrackId === state.tracks[index].id) {
        if (el.audio.paused) playAudio();
      } else {
        loadTrack(index, true);
      }
    });

    el.playlistList.addEventListener('keydown', function (event) {
      var row = event.target.closest('.track-row');
      if (!row) return;
      if (event.key === 'Enter') {
        event.preventDefault();
        loadTrack(Number(row.dataset.index), true);
      }
      if (event.key === 'Delete') {
        event.preventDefault();
        state.selected = Number(row.dataset.index);
        removeSelectedTrack();
      }
    });

    el.playlistList.addEventListener('dragstart', function (event) {
      var row = event.target.closest('.track-row');
      if (!row) return;
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('application/x-qianqian-track', row.dataset.index);
      event.dataTransfer.setData('text/plain', row.dataset.index);
      row.classList.add('dragging');
    });

    el.playlistList.addEventListener('dragend', function () {
      $$('.track-row', el.playlistList).forEach(function (row) {
        row.classList.remove('dragging', 'drag-over');
      });
    });

    el.playlistList.addEventListener('dragover', function (event) {
      var row = event.target.closest('.track-row');
      if (!row) return;
      if (event.dataTransfer && event.dataTransfer.types.indexOf('application/x-qianqian-track') !== -1) {
        event.preventDefault();
        event.dataTransfer.dropEffect = 'move';
        $$('.track-row.drag-over', el.playlistList).forEach(function (item) { item.classList.remove('drag-over'); });
        row.classList.add('drag-over');
      }
    });

    el.playlistList.addEventListener('dragleave', function (event) {
      var row = event.target.closest('.track-row');
      if (row) row.classList.remove('drag-over');
    });

    el.playlistList.addEventListener('drop', function (event) {
      var row = event.target.closest('.track-row');
      if (!row) return;
      var raw = event.dataTransfer.getData('application/x-qianqian-track');
      if (!raw) return;
      event.preventDefault();
      event.stopPropagation();
      var from = Number(raw);
      var to = Number(row.dataset.index);
      moveTrack(from, to);
    });

    el.removeBtn.addEventListener('click', removeSelectedTrack);
    el.clearBtn.addEventListener('click', clearPlaylist);
    el.playlistEmpty.addEventListener('click', function (event) {
      var button = event.target.closest('[data-action]');
      if (!button) return;
      handleAction(button.getAttribute('data-action'));
    });
  }

  function moveTrack(from, to) {
    if (from === to || from < 0 || to < 0 || from >= state.tracks.length || to >= state.tracks.length) return;
    var currentId = currentTrack() ? currentTrack().id : null;
    var selectedTrack = state.tracks[state.selected] || null;
    var moved = state.tracks.splice(from, 1)[0];
    state.tracks.splice(to, 0, moved);
    if (currentId) {
      state.current = state.tracks.findIndex(function (track) { return track.id === currentId; });
    }
    if (selectedTrack) {
      state.selected = state.tracks.findIndex(function (track) { return track.id === selectedTrack.id; });
    }
    renderPlaylist(true);
    showToast('已调整播放顺序');
  }

  function removeSelectedTrack() {
    var index = state.selected >= 0 ? state.selected : state.current;
    if (index < 0 || index >= state.tracks.length) return;
    removeTrackAt(index);
  }

  function removeTrackAt(index) {
    var track = state.tracks[index];
    if (!track) return;
    var wasPlaying = !el.audio.paused && state.current === index;
    var wasCurrent = state.current === index;
    if (wasCurrent) el.audio.pause();
    revokeTrack(track);
    state.tracks.splice(index, 1);

    if (wasCurrent) {
      state.current = -1;
      state.loadedTrackId = null;
      state.selected = -1;
      try {
        el.audio.removeAttribute('src');
        el.audio.load();
      } catch (error) { /* ignore */ }
      resetProgress(0);
    } else {
      if (state.current > index) state.current -= 1;
      if (state.selected > index) state.selected -= 1;
    }

    if (!state.tracks.length) {
      clearCurrentDisplay();
      renderPlaylist(false);
      showToast('已移除「' + track.title + '」');
      return;
    }

    if (wasCurrent) {
      var nextIndex = Math.min(index, state.tracks.length - 1);
      state.selected = nextIndex;
      loadTrack(nextIndex, wasPlaying);
      if (wasPlaying) {
        // loadTrack already calls playAudio through the autoplay argument.
      }
    } else {
      renderCurrentInfo();
      renderPlaylist(true);
    }
    showToast('已移除「' + track.title + '」');
  }

  function clearCurrentDisplay() {
    state.current = -1;
    state.selected = -1;
    state.loadedTrackId = null;
    state.lyricActive = -1;
    state.lyricEls = [];
    state.playing = false;
    el.body.classList.remove('is-playing');
    el.audio.pause();
    try {
      el.audio.removeAttribute('src');
      el.audio.load();
    } catch (error) { /* ignore */ }
    resetProgress(0);
    renderCurrentInfo();
    renderLyrics();
    renderPlaylist(false);
    setStatus('就绪');
    el.nowState.textContent = '准备就绪';
  }

  function clearPlaylist() {
    if (!state.tracks.length) return;
    if (!window.confirm('清空整个播放列表？歌曲文件本身不会被删除。')) return;
    el.audio.pause();
    state.tracks.forEach(revokeTrack);
    state.tracks = [];
    state.query = '';
    el.playlistSearch.value = '';
    clearCurrentDisplay();
    showToast('播放列表已清空');
  }

  function revokeTrack(track) {
    if (!track) return;
    if (track.url && objectUrls.has(track.url)) {
      URL.revokeObjectURL(track.url);
      objectUrls.delete(track.url);
    }
    if (track.coverUrl && objectUrls.has(track.coverUrl)) {
      URL.revokeObjectURL(track.coverUrl);
      objectUrls.delete(track.coverUrl);
    }
  }

  /* =========================================================
     Import: files, folders, drag and drop
     ========================================================= */
  function bindImport() {
    el.fileInput.addEventListener('change', function () {
      var files = Array.prototype.slice.call(el.fileInput.files || []);
      el.fileInput.value = '';
      if (files.length) addSources(files.map(function (file) {
        return { file: file, path: file.webkitRelativePath || file.name };
      }));
    });

    el.folderInput.addEventListener('change', function () {
      var files = Array.prototype.slice.call(el.folderInput.files || []);
      el.folderInput.value = '';
      if (files.length) addSources(files.map(function (file) {
        return { file: file, path: file.webkitRelativePath || file.name };
      }));
    });

    el.lrcInput.addEventListener('change', async function () {
      var file = el.lrcInput.files && el.lrcInput.files[0];
      el.lrcInput.value = '';
      if (!file) return;
      if (!currentTrack()) {
        showToast('请先选择一首歌曲，再导入歌词', 'error');
        return;
      }
      try {
        var text = await readTextSmart(file);
        applyLrcText(currentTrack(), text, file.name);
        switchTab('lyrics', true);
        showToast('已导入歌词：' + file.name);
      } catch (error) {
        showToast('歌词文件读取失败', 'error');
      }
    });

    bindDragAndDrop();
  }

  async function addSources(sources) {
    var lrcFiles = [];
    var audioSources = [];
    sources.forEach(function (source) {
      if (!source || !source.file) return;
      if (isLrc(source.file.name)) {
        lrcFiles.push(source);
      } else if (isAudio(source.file.name)) {
        audioSources.push(source);
      }
    });

    if (!audioSources.length) {
      if (lrcFiles.length && currentTrack()) {
        try {
          var text = await readTextSmart(lrcFiles[0].file);
          applyLrcText(currentTrack(), text, lrcFiles[0].file.name);
          switchTab('lyrics', true);
          showToast('已为当前歌曲导入歌词');
        } catch (error) {
          showToast('歌词文件读取失败', 'error');
        }
      } else if (lrcFiles.length) {
        showToast('请先选择一首歌曲，再导入歌词', 'error');
      } else {
        showToast('没有找到可播放的音频文件', 'error');
      }
      return;
    }

    var index = buildLrcIndex(lrcFiles);
    var added = [];
    var duplicates = 0;
    audioSources.forEach(function (source) {
      var key = makeFileKey(source.file);
      if (state.tracks.some(function (track) { return track.key === key; })) {
        duplicates += 1;
        return;
      }
      var lrc = findLrcFor(source, index);
      var track = createFileTrack(source, lrc ? lrc.file : null);
      state.tracks.push(track);
      added.push(track);
      if (lrc) track.lrcSource = lrc.path;
    });

    if (!added.length) {
      showToast(duplicates ? '这些歌曲已经在播放列表里了' : '没有添加新的歌曲', 'error');
      return;
    }

    var wasEmpty = state.current < 0;
    renderPlaylist(true);
    if (wasEmpty) {
      var firstAddedIndex = state.tracks.indexOf(added[0]);
      loadTrack(firstAddedIndex, false);
    }
    if (added.length === 1) {
      showToast('已添加：' + added[0].title + (added[0].lrcFile ? ' · 已匹配歌词' : ''));
    } else {
      showToast('已添加 ' + added.length + ' 首歌曲' + (duplicates ? '，跳过 ' + duplicates + ' 首重复' : ''));
    }
    hydrateTracks(added);
  }

  function buildLrcIndex(lrcSources) {
    var full = new Map();
    var base = new Map();
    lrcSources.forEach(function (source) {
      var path = normalizePath(source.path || source.file.name);
      var key = stripExt(path).toLowerCase();
      if (!full.has(key)) full.set(key, source);
      var baseKey = stripExt(basename(path)).toLowerCase();
      if (!base.has(baseKey)) base.set(baseKey, source);
      else if (base.get(baseKey) !== source) base.set(baseKey, null);
    });
    return { full: full, base: base };
  }

  function findLrcFor(audioSource, index) {
    var path = normalizePath(audioSource.path || audioSource.file.name);
    var exact = index.full.get(stripExt(path).toLowerCase());
    if (exact) return exact;
    var baseKey = stripExt(basename(path)).toLowerCase();
    return index.base.get(baseKey) || null;
  }

  function hydrateTracks(tracks) {
    tracks.forEach(function (track) { state.hydrateQueue.push(track); });
    drainHydrationQueue();
  }

  function drainHydrationQueue() {
    while (state.hydrateActive < 3 && state.hydrateQueue.length) {
      (function (track) {
        state.hydrateActive += 1;
        hydrateTrack(track).catch(function () { /* metadata is optional */ }).then(function () {
          state.hydrateActive -= 1;
          drainHydrationQueue();
        });
      })(state.hydrateQueue.shift());
    }
  }

  async function hydrateTrack(track) {
    if (!track || track.hydrated || !track.file) return;
    track.hydrated = true;
    var jobs = [
      window.ID3 ? window.ID3.read(track.file).catch(function () { return {}; }) : Promise.resolve({}),
      probeDuration(track.url).catch(function () { return 0; })
    ];
    if (track.lrcFile) {
      jobs.push(readTextSmart(track.lrcFile).catch(function () { return null; }));
    } else {
      jobs.push(Promise.resolve(null));
    }
    var results = await Promise.all(jobs);
    var tags = results[0] || {};
    var duration = results[1] || 0;
    var lrcText = results[2];

    if (tags.title) track.title = tags.title;
    if (tags.artist) track.artist = tags.artist;
    if (tags.album) track.album = tags.album;
    if (tags.year) track.year = tags.year;
    if (tags.track) track.trackNumber = tags.track;
    if (duration > 0) track.duration = Math.round(duration * 10) / 10;
    if (tags.cover) {
      try {
        track.coverUrl = URL.createObjectURL(tags.cover);
        objectUrls.add(track.coverUrl);
      } catch (error) {
        track.coverUrl = null;
      }
    }
    if (lrcText) {
      applyLrcText(track, lrcText, track.lrcFile.name);
    }
    if (state.current >= 0 && state.tracks[state.current] === track) {
      renderCurrentInfo();
      if (track.lyrics) renderLyrics();
      updateLyrics(true);
      if (duration > 0) renderProgress();
    }
    scheduleListRender();
  }

  function probeDuration(url) {
    return new Promise(function (resolve) {
      var probe = new Audio();
      var finished = false;
      var timer = setTimeout(function () { finish(0); }, 12000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        probe.onloadedmetadata = null;
        probe.onerror = null;
        probe.removeAttribute('src');
        try { probe.load(); } catch (error) { /* ignore */ }
        resolve(value);
      }
      probe.preload = 'metadata';
      probe.onloadedmetadata = function () {
        finish(Number.isFinite(probe.duration) ? probe.duration : 0);
      };
      probe.onerror = function () { finish(0); };
      probe.src = url;
    });
  }

  function applyLrcText(track, text, source) {
    if (!track) return;
    var parsed = parseLRC(text);
    track.lrcText = text;
    track.lyrics = parsed.lines;
    track.lrcSource = source || '手动导入';
    if (parsed.meta.offset && Number.isFinite(parsed.meta.offset)) {
      track.lyricOffset = clamp(parsed.meta.offset / 1000, -10, 10);
    }
    if (currentTrack() === track) {
      renderLyrics();
      updateLyrics(true);
    }
    scheduleListRender();
  }

  /* Drag and drop, including folders. */
  function bindDragAndDrop() {
    var hasFiles = function (event) {
      if (!event.dataTransfer || !event.dataTransfer.types) return false;
      return Array.prototype.indexOf.call(event.dataTransfer.types, 'Files') !== -1;
    };

    window.addEventListener('dragenter', function (event) {
      if (!hasFiles(event)) return;
      event.preventDefault();
      state.dragDepth += 1;
      el.dragOverlay.classList.add('is-visible');
      el.dragOverlay.setAttribute('aria-hidden', 'false');
    });
    window.addEventListener('dragover', function (event) {
      if (hasFiles(event)) {
        event.preventDefault();
        event.dataTransfer.dropEffect = 'copy';
      }
    });
    window.addEventListener('dragleave', function (event) {
      if (!hasFiles(event)) return;
      state.dragDepth = Math.max(0, state.dragDepth - 1);
      if (state.dragDepth === 0) {
        el.dragOverlay.classList.remove('is-visible');
        el.dragOverlay.setAttribute('aria-hidden', 'true');
      }
    });
    window.addEventListener('drop', async function (event) {
      if (!hasFiles(event)) return;
      event.preventDefault();
      state.dragDepth = 0;
      el.dragOverlay.classList.remove('is-visible');
      el.dragOverlay.setAttribute('aria-hidden', 'true');
      try {
        var sources = await readDroppedSources(event.dataTransfer);
        if (sources.length) addSources(sources);
      } catch (error) {
        showToast('读取拖入的文件失败', 'error');
      }
    });
  }

  async function readDroppedSources(dataTransfer) {
    var items = dataTransfer.items;
    if (items && items.length && items[0].webkitGetAsEntry) {
      var roots = [];
      for (var i = 0; i < items.length; i++) {
        if (items[i].kind !== 'file') continue;
        var entry = items[i].webkitGetAsEntry();
        if (entry) roots.push(entry);
      }
      if (roots.length) {
        var lists = await Promise.all(roots.map(function (entry) { return walkEntry(entry, ''); }));
        return lists.reduce(function (all, list) { return all.concat(list); }, []);
      }
    }
    return Array.prototype.slice.call(dataTransfer.files || []).map(function (file) {
      return { file: file, path: file.name };
    });
  }

  function walkEntry(entry, prefix) {
    return new Promise(function (resolve) {
      if (entry.isFile) {
        entry.file(function (file) {
          resolve([{ file: file, path: normalizePath(prefix + file.name) }]);
        }, function () { resolve([]); });
        return;
      }
      if (!entry.isDirectory) {
        resolve([]);
        return;
      }
      var reader = entry.createReader();
      var all = [];
      var readBatch = function () {
        reader.readEntries(async function (entries) {
          if (!entries.length) {
            resolve(all);
            return;
          }
          var children = await Promise.all(entries.map(function (child) {
            return walkEntry(child, prefix + entry.name + '/');
          }));
          all = all.concat.apply(all, children);
          readBatch();
        }, function () { resolve(all); });
      };
      readBatch();
    });
  }

  /* =========================================================
     Lyrics
     ========================================================= */
  function parseLRC(text) {
    var meta = {};
    var entries = [];
    var offset = 0;
    var rawLines = String(text || '').replace(/^\uFEFF/, '').split(/\r?\n/);
    rawLines.forEach(function (raw) {
      var line = raw.trim();
      if (!line) return;
      var metaMatch = line.match(/^\[(ti|ar|al|by|offset):(.*)\]$/i);
      if (metaMatch) {
        meta[metaMatch[1].toLowerCase()] = metaMatch[2].trim();
        if (metaMatch[1].toLowerCase() === 'offset') {
          offset = Number(metaMatch[2]) || 0;
        }
        return;
      }
      var timePattern = /\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g;
      var times = [];
      var match;
      while ((match = timePattern.exec(line)) !== null) {
        var minutes = Number(match[1]) || 0;
        var seconds = Number(match[2]) || 0;
        var fraction = match[3] ? Number(('0.' + match[3])) : 0;
        times.push(minutes * 60 + seconds + fraction);
      }
      var content = line.replace(/\[[^\]]*\]/g, '').trim();
      if (!times.length || !content) return;
      times.forEach(function (time) {
        entries.push({ time: time, text: content });
      });
    });
    entries.sort(function (a, b) { return a.time - b.time; });
    var merged = [];
    entries.forEach(function (entry) {
      var last = merged[merged.length - 1];
      if (last && Math.abs(last.time - entry.time) < 0.001) {
        if (last.text.indexOf(entry.text) === -1) last.text += ' / ' + entry.text;
      } else {
        merged.push(entry);
      }
    });
    meta.offset = offset;
    return { lines: merged, meta: meta };
  }

  function ensureLyrics(track) {
    if (!track) return [];
    if (Array.isArray(track.lyrics)) return track.lyrics;
    if (track.lrcText) {
      var parsed = parseLRC(track.lrcText);
      track.lyrics = parsed.lines;
      return track.lyrics;
    }
    track.lyrics = [];
    return track.lyrics;
  }

  function renderLyrics() {
    var track = currentTrack();
    el.lyricsLines.textContent = '';
    el.lyricEls = [];
    state.lyricActive = -1;

    if (!track) {
      el.lyricsEmpty.hidden = false;
      el.lyricsEmpty.querySelector('h3').textContent = '还没有选择歌曲';
      el.lyricsEmpty.querySelector('p').innerHTML = '从播放列表选择一首歌，<br>再导入它的 LRC 歌词。';
      el.syncState.classList.remove('is-synced');
      el.syncState.querySelector('span:last-child').textContent = '未载入歌词';
      el.offsetValue.textContent = '0.0s';
      updateLyricStripState();
      return;
    }

    var lines = ensureLyrics(track);
    if (!lines.length) {
      el.lyricsEmpty.hidden = false;
      el.lyricsEmpty.querySelector('h3').textContent = '还没有歌词';
      el.lyricsEmpty.querySelector('p').innerHTML = '把同名 LRC 文件和歌曲一起添加，<br>或在这里手动导入。';
      el.syncState.classList.remove('is-synced');
      el.syncState.querySelector('span:last-child').textContent = '未载入歌词';
      el.offsetValue.textContent = formatOffset(track.lyricOffset || 0);
      updateLyricStripState();
      return;
    }

    el.lyricsEmpty.hidden = true;
    var fragment = document.createDocumentFragment();
    lines.forEach(function (line, index) {
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'lyrics-line';
      button.dataset.time = String(line.time);
      button.dataset.index = String(index);
      button.textContent = line.text;
      button.title = '跳到 ' + formatTime(line.time);
      fragment.appendChild(button);
      el.lyricEls.push(button);
    });
    el.lyricsLines.appendChild(fragment);
    el.syncState.classList.add('is-synced');
    el.syncState.querySelector('span:last-child').textContent = '同步歌词';
    el.offsetValue.textContent = formatOffset(track.lyricOffset || 0);
    el.lyricsScroll.scrollTop = 0;
    state.lyricActive = -1;
    updateLyrics(true);
    requestAnimationFrame(function () { scrollActiveLyric(false); });
  }

  function findLyricIndex(lines, time) {
    var low = 0;
    var high = lines.length - 1;
    var result = -1;
    while (low <= high) {
      var middle = (low + high) >> 1;
      if (lines[middle].time <= time + 0.03) {
        result = middle;
        low = middle + 1;
      } else {
        high = middle - 1;
      }
    }
    return result;
  }

  function updateLyrics(force) {
    var track = currentTrack();
    var lines = track ? ensureLyrics(track) : [];
    if (!track || !lines.length) {
      updateLyricStripState();
      return;
    }
    var offset = Number(track.lyricOffset) || 0;
    var time = (el.audio.currentTime || 0) - offset;
    var index = findLyricIndex(lines, time);
    if (index < 0) index = -1;
    if (!force && index === state.lyricActive) {
      return;
    }
    var previous = state.lyricActive;
    state.lyricActive = index;

    if (previous >= 0 && el.lyricEls[previous]) {
      el.lyricEls[previous].classList.remove('is-active');
    }
    el.lyricEls.forEach(function (line, lineIndex) {
      line.classList.toggle('is-near', Math.abs(lineIndex - index) === 1);
    });
    if (index >= 0 && el.lyricEls[index]) {
      el.lyricEls[index].classList.add('is-active');
      if (el.lyricStripText) {
        el.lyricStripText.textContent = lines[index].text;
        el.lyricStrip.classList.add('is-live');
      }
    } else {
      el.lyricStripText.textContent = lines[0] ? lines[0].text : '暂无同步歌词';
      el.lyricStrip.classList.remove('is-live');
    }
    updateLyricStripState();
    if (Date.now() > state.lyricManualUntil && !document.getElementById('panel-lyrics').hidden) {
      scrollActiveLyric(true);
    }
  }

  function scrollActiveLyric(smooth) {
    if (state.lyricActive < 0 || !el.lyricEls[state.lyricActive]) return;
    var line = el.lyricEls[state.lyricActive];
    var top = line.offsetTop - el.lyricsScroll.clientHeight * 0.44;
    el.lyricsScroll.scrollTo({ top: Math.max(0, top), behavior: smooth ? 'smooth' : 'auto' });
  }

  function updateLyricStripState() {
    var track = currentTrack();
    if (!track) {
      el.lyricStrip.classList.remove('is-live');
      el.lyricStripText.textContent = '暂无同步歌词 · 可在歌词页导入 LRC 文件';
      return;
    }
    if (!ensureLyrics(track).length) {
      el.lyricStrip.classList.remove('is-live');
      el.lyricStripText.textContent = '暂无同步歌词 · 可在歌词页导入 LRC 文件';
    }
  }

  function changeLyricOffset(delta) {
    var track = currentTrack();
    if (!track) return;
    track.lyricOffset = clamp((track.lyricOffset || 0) + delta, -10, 10);
    el.offsetValue.textContent = formatOffset(track.lyricOffset);
    state.lyricActive = -2;
    updateLyrics(true);
    if (el.lyricEls[state.lyricActive]) scrollActiveLyric(true);
  }

  function bindLyrics() {
    el.lyricsLines.addEventListener('click', function (event) {
      var line = event.target.closest('.lyrics-line');
      if (!line) return;
      var track = currentTrack();
      if (!track) return;
      var time = Number(line.dataset.time) + (track.lyricOffset || 0);
      try { el.audio.currentTime = Math.max(0, time); } catch (error) { /* ignore */ }
      renderProgress();
      state.lyricActive = -2;
      updateLyrics(true);
      if (el.audio.paused) showToast('已定位到歌词：' + formatTime(time));
    });
    var markManual = function () {
      state.lyricManualUntil = Date.now() + 4200;
    };
    el.lyricsScroll.addEventListener('wheel', markManual, { passive: true });
    el.lyricsScroll.addEventListener('touchmove', markManual, { passive: true });
    el.lyricsScroll.addEventListener('pointerdown', markManual);
    $('btn-offset-minus').addEventListener('click', function () { changeLyricOffset(-0.2); });
    $('btn-offset-plus').addEventListener('click', function () { changeLyricOffset(0.2); });
  }

  /* =========================================================
     Tabs and views
     ========================================================= */
  function switchTab(tab, silent) {
    if (['playlist', 'lyrics', 'eq'].indexOf(tab) === -1) tab = 'playlist';
    state.tab = tab;
    el.tabButtons.forEach(function (button) {
      var active = button.dataset.tab === tab;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    el.tabPanels.forEach(function (panel) {
      panel.hidden = panel.id !== 'panel-' + tab;
      panel.classList.toggle('is-active', panel.id === 'panel-' + tab);
    });
    if (tab === 'lyrics') {
      if (!state.lyricEls.length) renderLyrics();
      requestAnimationFrame(function () {
        updateLyrics(true);
        scrollActiveLyric(false);
      });
    }
    saveSettings();
    if (!silent && tab === 'eq') {
      paintEqValues();
    }
  }

  function bindTabs() {
    el.tabButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        switchTab(button.dataset.tab);
      });
    });
    el.lyricStrip.addEventListener('click', function () {
      switchTab('lyrics');
    });
  }

  /* =========================================================
     Menus and window actions
     ========================================================= */
  function closeMenus() {
    el.menuTriggers.forEach(function (trigger) {
      trigger.classList.remove('is-open');
      trigger.setAttribute('aria-expanded', 'false');
    });
    el.menuPopovers.forEach(function (popover) {
      popover.classList.remove('is-open');
    });
  }

  function openMenu(name) {
    var trigger = el.menuTriggers.filter(function (item) { return item.dataset.menu === name; })[0];
    var popover = $('menu-' + name);
    if (!trigger || !popover) return;
    var alreadyOpen = trigger.classList.contains('is-open');
    closeMenus();
    if (alreadyOpen) return;
    trigger.classList.add('is-open');
    trigger.setAttribute('aria-expanded', 'true');
    popover.classList.add('is-open');
  }

  function bindMenus() {
    el.menuTriggers.forEach(function (trigger) {
      trigger.addEventListener('click', function (event) {
        event.stopPropagation();
        openMenu(trigger.dataset.menu);
      });
      trigger.addEventListener('mouseenter', function () {
        var anyOpen = el.menuTriggers.some(function (item) { return item.classList.contains('is-open'); });
        if (anyOpen) openMenu(trigger.dataset.menu);
      });
    });
    document.addEventListener('click', function (event) {
      if (!event.target.closest('.menu-wrap')) closeMenus();
    });
    document.addEventListener('click', function (event) {
      var actionEl = event.target.closest('[data-action]');
      if (!actionEl) return;
      if (actionEl.closest('.menu-popover')) closeMenus();
      handleAction(actionEl.getAttribute('data-action'));
    });
  }

  /* Optional native shell (the packaged EXE) window bridge. */
  function postNative(action) {
    if (!nativeBridge) return;
    try {
      nativeBridge.postMessage({ type: 'window', action: action });
    } catch (error) {
      // Browser mode has no native window.
    }
  }

  function setNativeMaximized(maximized) {
    el.body.classList.toggle('maximized', !!maximized);
    var maximizeButton = $('btn-maximize');
    if (maximizeButton) {
      maximizeButton.title = maximized ? '还原窗口' : '最大化';
      maximizeButton.setAttribute('aria-label', maximized ? '还原窗口' : '最大化');
    }
  }

  function bindNativeShell() {
    if (!nativeBridge) return;
    el.body.classList.add('native-shell');
    var titlebar = document.querySelector('.titlebar');
    if (titlebar) {
      titlebar.addEventListener('mousedown', function (event) {
        if (event.button !== 0) return;
        if (event.target.closest('.window-controls')) return;
        if (event.target.closest('button, a, input, select')) return;
        event.preventDefault();
        postNative('drag');
      });
      titlebar.addEventListener('dblclick', function (event) {
        if (event.target.closest('.window-controls')) return;
        if (event.target.closest('button, a, input, select')) return;
        postNative('toggle-maximize');
      });
    }
    nativeBridge.addEventListener('message', function (event) {
      var message = event.data;
      if (!message) return;
      if (typeof message === 'string') {
        if (message.indexOf('maximized') !== -1) setNativeMaximized(true);
        if (message.indexOf('normal') !== -1) setNativeMaximized(false);
        return;
      }
      if (message.type === 'window-state') {
        setNativeMaximized(message.value === 'maximized');
      }
    });
  }

  function handleAction(action) {
    switch (action) {
      case 'open-files':
        el.fileInput.click();
        break;
      case 'open-folder':
        el.folderInput.click();
        break;
      case 'import-lrc':
        el.lrcInput.click();
        break;
      case 'toggle-play':
        togglePlay();
        break;
      case 'stop':
        stopPlayback();
        break;
      case 'prev':
        previousTrack();
        break;
      case 'next':
        nextTrack(true);
        break;
      case 'mode-sequence':
      case 'mode-repeat-all':
      case 'mode-repeat-one':
      case 'mode-shuffle':
        setMode(action.replace('mode-', ''));
        showToast('播放模式：' + (MODES.filter(function (item) { return item.id === state.mode; })[0] || {}).label);
        break;
      case 'show-playlist':
        switchTab('playlist');
        break;
      case 'show-lyrics':
        switchTab('lyrics');
        break;
      case 'show-eq':
        switchTab('eq');
        break;
      case 'mini-mode':
        enterMiniMode();
        break;
      case 'fullscreen':
        toggleFullscreen();
        break;
      case 'shortcuts':
        openModal(el.shortcutsModal);
        break;
      case 'about':
        openModal(el.aboutModal);
        break;
      case 'exit':
        closeApp();
        break;
      default:
        break;
    }
  }

  function bindTransport() {
    el.playBtn.addEventListener('click', togglePlay);
    el.prevBtn.addEventListener('click', previousTrack);
    el.nextBtn.addEventListener('click', function () { nextTrack(true); });
    el.stopBtn.addEventListener('click', stopPlayback);
    el.modeBtn.addEventListener('click', cycleMode);
    el.favoriteBtn.addEventListener('click', setFavoriteState);
    el.miniPlay.addEventListener('click', togglePlay);
    el.miniPrev.addEventListener('click', previousTrack);
    el.miniNext.addEventListener('click', function () { nextTrack(true); });
    $('btn-minimize').addEventListener('click', function () {
      if (nativeBridge) postNative('minimize');
      else enterMiniMode();
    });
    $('btn-maximize').addEventListener('click', function () {
      if (nativeBridge) postNative('toggle-maximize');
      else toggleFullscreen();
    });
    $('btn-close').addEventListener('click', function () {
      if (nativeBridge) postNative('close');
      else closeApp();
    });
    $('btn-restore').addEventListener('click', exitMiniMode);
    el.mini.addEventListener('dblclick', function (event) {
      if (event.target.closest('button')) return;
      exitMiniMode();
    });
    $('btn-restart').addEventListener('click', function () {
      el.body.classList.remove('closed');
      el.exitScreen.setAttribute('aria-hidden', 'true');
      el.app.focus();
      showToast('千千静听已回到桌面');
    });
    $('btn-eq-reset').addEventListener('click', function () {
      setEqPreset('flat');
    });
  }

  function enterMiniMode() {
    el.body.classList.add('mini-mode');
    updateMini();
    el.mini.focus();
  }

  function exitMiniMode() {
    el.body.classList.remove('mini-mode');
    el.playBtn.focus();
  }

  function closeApp() {
    el.audio.pause();
    el.body.classList.remove('mini-mode');
    el.body.classList.add('closed');
    el.exitScreen.setAttribute('aria-hidden', 'false');
    setStatus('已退出');
  }

  async function toggleFullscreen() {
    if (nativeBridge) {
      postNative('toggle-maximize');
      return;
    }
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch (error) {
      el.body.classList.toggle('maximized');
    }
  }

  function openModal(modal) {
    if (!modal) return;
    modal.hidden = false;
    var closeButton = modal.querySelector('[data-close-modal]');
    if (closeButton) closeButton.focus();
  }

  function closeModal(modal) {
    if (!modal) return;
    modal.hidden = true;
    el.playBtn.focus();
  }

  function bindModals() {
    $$('.modal-backdrop').forEach(function (backdrop) {
      backdrop.addEventListener('click', function (event) {
        if (event.target === backdrop) closeModal(backdrop);
      });
    });
    $$('[data-close-modal]').forEach(function (button) {
      button.addEventListener('click', function () {
        var modal = button.closest('.modal-backdrop');
        closeModal(modal);
      });
    });
  }

  /* =========================================================
     EQ UI
     ========================================================= */
  function bindEq() {
    el.eqSliders.forEach(function (slider) {
      slider.addEventListener('input', function () {
        var index = Number(slider.dataset.band);
        var bandIndex = EQ_FREQUENCIES.indexOf(index);
        if (bandIndex === -1) return;
        var value = Number(slider.value);
        state.eqBands[bandIndex] = value;
        var preset = matchPreset(state.eqBands);
        state.eqPreset = preset;
        el.eqPreset.value = preset;
        paintEqValues();
        applyEQ();
        saveSettings();
      });
    });
    el.eqPreset.addEventListener('change', function () {
      setEqPreset(el.eqPreset.value);
    });
    el.eqEnable.addEventListener('click', function () {
      setEqEnabled(!state.eqEnabled, true);
    });
  }

  /* =========================================================
     Spectrum visualizer
     ========================================================= */
  function setupSpectrum() {
    state.spectrumCtx = el.spectrum.getContext('2d');
    var resize = function () {
      var rect = el.spectrum.getBoundingClientRect();
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      var width = Math.max(160, Math.floor(rect.width));
      var height = Math.max(40, Math.floor(rect.height));
      el.spectrum.width = Math.floor(width * dpr);
      el.spectrum.height = Math.floor(height * dpr);
      var ctx = state.spectrumCtx;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      state.spectrumWidth = width;
      state.spectrumHeight = height;
    };
    resize();
    if (window.ResizeObserver) {
      new ResizeObserver(resize).observe(el.spectrum);
    } else {
      window.addEventListener('resize', resize);
    }
    requestAnimationFrame(spectrumLoop);
  }

  function spectrumLoop(timestamp) {
    drawSpectrum(timestamp || 0);
    requestAnimationFrame(spectrumLoop);
  }

  function drawSpectrum(timestamp) {
    var ctx = state.spectrumCtx;
    if (!ctx) return;
    var width = state.spectrumWidth || 500;
    var height = state.spectrumHeight || 90;
    ctx.clearRect(0, 0, width, height);

    var bg = ctx.createLinearGradient(0, 0, 0, height);
    bg.addColorStop(0, 'rgba(7, 24, 34, .18)');
    bg.addColorStop(1, 'rgba(2, 10, 15, .55)');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = 'rgba(100, 180, 170, .08)';
    ctx.lineWidth = 1;
    for (var line = 1; line <= 3; line++) {
      var yLine = Math.round(height * line / 4) + 0.5;
      ctx.beginPath();
      ctx.moveTo(0, yLine);
      ctx.lineTo(width, yLine);
      ctx.stroke();
    }

    var count = Math.max(34, Math.min(62, Math.floor(width / 8)));
    if (state.spectrumLevels.length !== count) {
      state.spectrumLevels = new Array(count).fill(0.06);
      state.spectrumPeaks = new Array(count).fill(0);
    }

    var data = null;
    if (state.analyser && state.playing) {
      state.analyser.getByteFrequencyData(state.frequencyData);
      data = state.frequencyData;
    }

    var gap = Math.max(2, Math.round(width / count * 0.28));
    var barWidth = (width - gap * (count - 1)) / count;
    var usableHeight = height - 15;
    var gradient = ctx.createLinearGradient(0, height - 4, 0, 6);
    gradient.addColorStop(0, 'rgba(27, 126, 127, .88)');
    gradient.addColorStop(0.45, 'rgba(63, 219, 185, .95)');
    gradient.addColorStop(0.82, 'rgba(145, 247, 193, .95)');
    gradient.addColorStop(1, 'rgba(225, 255, 183, .98)');

    for (var i = 0; i < count; i++) {
      var value;
      if (data && data.length) {
        var ratio = i / Math.max(1, count - 1);
        var bin = Math.floor(2 + Math.pow(ratio, 1.65) * (Math.floor(data.length * 0.7) - 2));
        value = (data[bin] || 0) / 255;
        value = Math.pow(value, 0.83);
        if (ratio < 0.12) value *= 1.13;
      } else {
        value = 0.035 + 0.035 * (0.5 + 0.5 * Math.sin(timestamp / 900 + i * 0.48)) +
          0.018 * (0.5 + 0.5 * Math.sin(timestamp / 1700 + i * 0.17));
      }
      var level = state.spectrumLevels[i] * 0.68 + value * 0.32;
      state.spectrumLevels[i] = level;
      var barHeight = Math.max(2, level * usableHeight);
      var x = i * (barWidth + gap);
      var y = height - 5 - barHeight;
      ctx.fillStyle = gradient;
      ctx.fillRect(x, y, Math.max(1, barWidth), barHeight);

      // Bright cap, like the old LED spectrum.
      ctx.fillStyle = 'rgba(226, 255, 199, ' + (0.35 + level * 0.62) + ')';
      ctx.fillRect(x, y, Math.max(1, barWidth), Math.min(1.5, barHeight));

      var peak = state.spectrumPeaks[i];
      if (barHeight > peak) peak = barHeight;
      else peak = Math.max(0, peak - 0.75);
      state.spectrumPeaks[i] = peak;
      if (peak > 4) {
        ctx.fillStyle = 'rgba(183, 255, 202, .24)';
        ctx.fillRect(x, height - 5 - peak, Math.max(1, barWidth), 1);
      }

      // Faint reflection below the baseline.
      if (barHeight > 8) {
        ctx.fillStyle = 'rgba(62, 214, 185, .07)';
        ctx.fillRect(x, height - 4, Math.max(1, barWidth), Math.min(9, barHeight * 0.14));
      }
    }

    ctx.strokeStyle = 'rgba(109, 224, 202, .14)';
    ctx.beginPath();
    ctx.moveTo(0, height - 4.5);
    ctx.lineTo(width, height - 4.5);
    ctx.stroke();
  }

  /* =========================================================
     Media Session
     ========================================================= */
  function updateMediaSession() {
    if (!('mediaSession' in navigator)) return;
    var track = currentTrack();
    if (!track) {
      try { navigator.mediaSession.metadata = null; } catch (error) { /* ignore */ }
      return;
    }
    try {
      var artwork = [];
      if (track.coverUrl) {
        artwork.push({ src: track.coverUrl, sizes: '512x512', type: track.coverUrl.indexOf('.svg') !== -1 ? 'image/svg+xml' : 'image/jpeg' });
      }
      navigator.mediaSession.metadata = new MediaMetadata({
        title: track.title || '未命名音频',
        artist: track.artist || '未知歌手',
        album: track.album || '本地音乐',
        artwork: artwork
      });
      navigator.mediaSession.playbackState = el.audio.paused ? 'paused' : 'playing';
    } catch (error) {
      // Media Session is a progressive enhancement.
    }
  }

  function bindMediaSession() {
    if (!('mediaSession' in navigator)) return;
    var handlers = {
      play: function () { playAudio(); },
      pause: function () { pauseAudio(); },
      previoustrack: previousTrack,
      nexttrack: function () { nextTrack(true); },
      seekbackward: function () { seekBy(-5); },
      seekforward: function () { seekBy(5); }
    };
    Object.keys(handlers).forEach(function (action) {
      try { navigator.mediaSession.setActionHandler(action, handlers[action]); } catch (error) { /* unsupported */ }
    });
    try {
      navigator.mediaSession.setActionHandler('seekto', function (details) {
        if (details && Number.isFinite(details.seekTime)) {
          el.audio.currentTime = details.seekTime;
          renderProgress();
        }
      });
    } catch (error) { /* unsupported */ }
  }

  /* =========================================================
     Keyboard
     ========================================================= */
  function bindKeyboard() {
    document.addEventListener('keydown', function (event) {
      if (event.defaultPrevented) return;
      var target = event.target;
      var typing = isFormField(target);
      var interactive = target && target.closest && target.closest('button, a, [role="button"], [role="option"]');

      if (event.key === 'Escape') {
        closeMenus();
        var openModalEl = $$('.modal-backdrop').filter(function (modal) { return !modal.hidden; })[0];
        if (openModalEl) {
          closeModal(openModalEl);
          return;
        }
        if (el.body.classList.contains('mini-mode')) {
          exitMiniMode();
          return;
        }
        if (el.body.classList.contains('closed')) return;
      }

      if (typing) return;

      if ((event.ctrlKey || event.metaKey) && !event.shiftKey && event.key.toLowerCase() === 'o') {
        event.preventDefault();
        el.fileInput.click();
        return;
      }
      if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key.toLowerCase() === 'o') {
        event.preventDefault();
        el.folderInput.click();
        return;
      }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'l') {
        event.preventDefault();
        el.lrcInput.click();
        return;
      }
      if (event.key === 'F11') {
        event.preventDefault();
        toggleFullscreen();
        return;
      }
      if ((event.ctrlKey || event.metaKey) && event.key === 'ArrowLeft') {
        event.preventDefault();
        previousTrack();
        return;
      }
      if ((event.ctrlKey || event.metaKey) && event.key === 'ArrowRight') {
        event.preventDefault();
        nextTrack(true);
        return;
      }
      if (event.key === '?' || (event.shiftKey && event.key === '/')) {
        event.preventDefault();
        openModal(el.shortcutsModal);
        return;
      }
      if (event.key === ' ' && !interactive) {
        event.preventDefault();
        togglePlay();
        return;
      }
      if (event.key === '/' && !typing) {
        event.preventDefault();
        switchTab('playlist');
        el.playlistSearch.focus();
        return;
      }
      if (event.key === 'ArrowLeft' && !event.ctrlKey) {
        event.preventDefault();
        seekBy(-5);
        return;
      }
      if (event.key === 'ArrowRight' && !event.ctrlKey) {
        event.preventDefault();
        seekBy(5);
        return;
      }
      if (event.key === 'ArrowUp') {
        event.preventDefault();
        changeVolume(0.04);
        return;
      }
      if (event.key === 'ArrowDown') {
        event.preventDefault();
        changeVolume(-0.04);
        return;
      }
      if (event.key === 'Delete') {
        event.preventDefault();
        removeSelectedTrack();
        return;
      }
      var key = event.key.toLowerCase();
      if (key === 'm') { event.preventDefault(); toggleMute(); return; }
      if (key === 'p') { event.preventDefault(); switchTab('playlist'); return; }
      if (key === 'l') { event.preventDefault(); switchTab('lyrics'); return; }
      if (key === 'e') { event.preventDefault(); switchTab('eq'); return; }
    });
  }

  /* =========================================================
     Clock and startup
     ========================================================= */
  function updateClock() {
    var now = new Date();
    el.statusClock.textContent = pad2(now.getHours()) + ':' + pad2(now.getMinutes());
  }

  function bindGlobalWindow() {
    document.addEventListener('fullscreenchange', function () {
      el.body.classList.toggle('maximized', !!document.fullscreenElement);
    });
    window.addEventListener('beforeunload', function () {
      state.tracks.forEach(revokeTrack);
    });
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) {
        resizeSpectrumSoon();
      }
    });
  }

  function resizeSpectrumSoon() {
    var rect = el.spectrum.getBoundingClientRect();
    if (!rect.width) return;
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    el.spectrum.width = Math.floor(rect.width * dpr);
    el.spectrum.height = Math.floor(rect.height * dpr);
    state.spectrumCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    state.spectrumWidth = Math.floor(rect.width);
    state.spectrumHeight = Math.floor(rect.height);
  }

  function restoreState() {
    setMode(state.mode);
    state.eqBands = state.eqBands.map(function (value) { return clamp(Number(value) || 0, -12, 12); });
    el.eqSliders.forEach(function (slider, index) {
      slider.value = String(state.eqBands[index]);
    });
    el.eqPreset.value = EQ_PRESETS[state.eqPreset] ? state.eqPreset : 'custom';
    paintEqValues();
    setEqEnabled(state.eqEnabled, false);
    updateVolumeUI();
    switchTab(state.tab, true);
  }

  function initDemo() {
    var demo = createDemoTrack();
    state.tracks.push(demo);
    state.current = 0;
    state.selected = 0;
    state.loadedTrackId = demo.id;
    try {
      el.audio.src = demo.url;
      el.audio.load();
    } catch (error) { /* no demo, no problem */ }
    ensureLyrics(demo);
    renderCurrentInfo();
    renderPlaylist(false);
    renderLyrics();
    renderProgress(demo.duration);
    setStatus('准备就绪');
    el.nowState.textContent = '准备就绪';
  }

  function init() {
    state.volume = clamp(Number(state.volume) || 0, 0, 1);
    el.audio.volume = state.volume;
    el.audio.muted = !!state.muted;
    bindProgress();
    bindPlaylist();
    bindImport();
    bindLyrics();
    bindTabs();
    bindMenus();
    bindModals();
    bindTransport();
    bindEq();
    bindKeyboard();
    bindMediaSession();
    bindGlobalWindow();
    bindNativeShell();
    setupSpectrum();
    restoreState();
    updateClock();
    setInterval(updateClock, 15000);
    initDemo();

    // Deep links for a specific panel, useful for bookmarks and screenshots.
    try {
      var requestedTab = new URLSearchParams(window.location.search).get('tab');
      if (requestedTab && ['playlist', 'lyrics', 'eq'].indexOf(requestedTab) !== -1) {
        switchTab(requestedTab, true);
      }
    } catch (error) {
      // Older browsers may not support URLSearchParams.
    }

    var visited = false;
    try { visited = localStorage.getItem(VISITED_KEY) === '1'; } catch (error) { visited = false; }
    if (!visited) {
      setTimeout(function () {
        showToast('已放入一首内置示例曲，双击列表或按播放试听');
      }, 700);
      try { localStorage.setItem(VISITED_KEY, '1'); } catch (error) { /* ignore */ }
    }

    // Expose a tiny debug surface for local experimentation, not a network API.
    window.QianQianClassic = {
      state: state,
      play: playAudio,
      pause: pauseAudio,
      next: function () { nextTrack(true); },
      previous: previousTrack,
      switchTab: switchTab,
      addFiles: function (files) {
        addSources(Array.prototype.slice.call(files).map(function (file) {
          return { file: file, path: file.name };
        }));
      }
    };
  }

  init();
})();
